<?php
return [
    'environment' => 'production', // production ou demo explícito; nunca fallback
    'url' => 'https://SEU-DOMINIO',
    'base_path' => '', // '/piscina' se instalado em subpasta
    'timezone' => 'America/Sao_Paulo',
    'database' => ['dsn' => 'mysql:host=localhost;dbname=SEU_BANCO;charset=utf8mb4', 'user' => '', 'password' => ''],
    'storage' => dirname(__DIR__) . '/storage',
    'session_path' => dirname(__DIR__) . '/storage/sessions',
    'secure_cookie' => true,
    // Tentativas de cadastro em 15 minutos: turma no mesmo Wi-Fi + proteção de e-mail e do sistema.
    'registration_limits' => ['per_ip' => 50, 'per_email' => 3, 'global' => 100],
    'smtp' => ['host' => '', 'port' => 587, 'username' => '', 'password' => '', 'encryption' => 'tls', 'from' => '', 'name' => 'Piscina de Liquidez'],
    'mail_transport' => 'smtp', // 'file' permitido somente em demo
    'galeria' => ['enabled' => false], // instale 004 e configure as condições antes de habilitar
    // Opcional, somente Admin. OAuth solicita test_token=true e exige live_mode=false antes de pagar.
    // Client Secret e Access Token nunca são enviados ao navegador ou incluídos nos ZIPs.
    'payments_test' => ['enabled'=>false, 'mode'=>'test', 'client_id'=>'', 'client_secret'=>'', 'collector_id'=>'', 'max_amount'=>'1000.00', 'payer_email'=>'pagador.teste@example.com', 'webhook_secret'=>''],
    'max_users' => 500, 'max_nfts' => 5000, 'snapshot_periods_per_run' => 10, 'upload_bytes' => 5242880, 'upload_pixels' => 16000000,
    'max_batch' => 100, 'cron_seconds' => 50,
    'http_tasks' => ['enabled' => false, 'token_hash' => ''], // bearer aleatório, somente hash privado
    'installation' => ['enabled' => false, 'token_hash' => '', 'expires_at' => ''], // sha256 de segredo temporário externo
];
