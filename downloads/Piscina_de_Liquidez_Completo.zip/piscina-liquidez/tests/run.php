<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli')exit(1);
putenv('PISCINA_CONFIG='.(getenv('PISCINA_CONFIG')?:__DIR__.'/local.php'));
require dirname(__DIR__).'/app/bootstrap.php';
if(config()['environment']!=='demo'||!preg_match('/dbname=piscina_test(?:;|$)/',config()['database']['dsn']))throw new RuntimeException('Use exclusivamente banco piscina_test e environment=demo. A suíte apaga esse banco.');
$db=db();$d=service();$tests=0;$failed=0;
function assertSame(mixed $expected,mixed $actual,string $why=''): void {if((string)$expected!==(string)$actual)throw new RuntimeException("$why esperado ".var_export($expected,true).' obtido '.var_export($actual,true));}
function check(bool $condition,string $why): void {if(!$condition)throw new RuntimeException($why);}
function testKey(): string {return bin2hex(random_bytes(16));}
function op(int $actor,string $action,array $data,?string $key=null): array {return service()->operation($actor,$action,$data,$key??testKey());}
function fail(callable $fn,int $status=409): void {try{$fn();}catch(Piscina\Problem $e){assertSame($status,$e->status,$e->getMessage());return;}throw new RuntimeException('Operação devia falhar.');}
function fresh(): void {
 db()->pdo->exec('SET timestamp=DEFAULT');
 $db=db();$db->pdo->exec('SET FOREIGN_KEY_CHECKS=0');foreach($db->all('SHOW TABLES')as $row)$db->pdo->exec('DROP TABLE `'.reset($row).'`');$db->pdo->exec('SET FOREIGN_KEY_CHECKS=1');(new Piscina\Installer($db,config()))->migrate();
 $db->run("INSERT INTO users(id,email,password_hash,display_name,role,email_verified_at,created_at) VALUES(1,'admin@local.invalid',?,'Admin','admin',UTC_TIMESTAMP(6),UTC_TIMESTAMP(6))",[password_hash('teste-admin-apenas',PASSWORD_DEFAULT)]);
 op(1,'admin.activate',['confirm'=>true,'rounding'=>'HALF_UP_CENT']);
}
function pending(string $name): int {db()->run('INSERT INTO users(email,password_hash,display_name,email_verified_at,created_at) VALUES(?,?,?,UTC_TIMESTAMP(6),UTC_TIMESTAMP(6))',[$name.'@local.invalid',password_hash('senha-local-testes',PASSWORD_DEFAULT),$name]);return (int)db()->pdo->lastInsertId();}
function user(string $name): array {$id=pending($name);$r=op(1,'admin.approve',['user_id'=>(string)$id]);return [$id,(int)$r['nft_id']];}
function balance(int $u,string $asset,string $purpose='available'): string {return service()->ledger->balances($u)[$asset][$purpose];}
function withdraw(int $u,int $nft,string $asset='MR'): array {$q=service()->quote($u,$nft);return op($u,'nft.withdraw',['nft_id'=>(string)$nft,'payment'=>$asset,'parameter_version'=>$q['parameter_version'],'quote_expires'=>$q['quote_expires']]);}
function proposal(int $buyer,int $seller,string $asset,string $quantity,string $price,bool $approve=true,?int $nft=null): array {return op($seller,'proposal.create',['buyer_id'=>(string)$buyer,'seller_id'=>(string)$seller,'asset'=>$asset,'quantity'=>$quantity,'unit_price'=>$price,'nft_id'=>$nft?(string)$nft:null,'expires_at'=>(new DateTimeImmutable(db()->now()))->modify('+1 hour')->format('Y-m-d\TH:i:s.u\Z'),'approve'=>$approve]);}
function sale(int $buyer,int $seller,string $asset,string $quantity,string $price,?int $nft=null): array {$p=proposal($buyer,$seller,$asset,$quantity,$price,true,$nft);return op($buyer,'proposal.approve',['proposal_id'=>$p['proposal_id'],'version'=>'1']);}
function period(): array {db()->run('UPDATE parameter_versions SET interval_minutes=1440,first_cutoff=DATE_SUB(UTC_TIMESTAMP(6),INTERVAL 1 SECOND) WHERE id=(SELECT x.id FROM (SELECT MAX(id) id FROM parameter_versions) x)');service()->periods->capture();while(service()->periods->processBatch(2)!==null){}return db()->row('SELECT * FROM periods ORDER BY id DESC LIMIT 1');}
function concurrent(array $calls): array {
 $dir=config()['storage'].'/tmp';if(!is_dir($dir))mkdir($dir,0700,true);$barrier=$dir.'/'.testKey().'.go';$procs=[];
 foreach($calls as $c){$path=$dir.'/'.testKey().'.json';$c['barrier']=$barrier;$c['key']??=testKey();file_put_contents($path,json_encode($c));$cmd=[PHP_BINARY,'-c',php_ini_loaded_file(),__DIR__.'/worker.php',$path];$pipes=[];$proc=proc_open($cmd,[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);fclose($pipes[0]);$procs[]=[$proc,$pipes,$path];}
 $deadline=microtime(true)+10;foreach($procs as [,, $p])while(!is_file($p.'.ready')){if(microtime(true)>$deadline)throw new RuntimeException('Worker não iniciou.');usleep(10000);}touch($barrier);$out=[];
 foreach($procs as [$proc,$pipes,$p]){$raw=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$code=proc_close($proc);if($code||!$raw)throw new RuntimeException('Worker: '.$err);$out[]=json_decode($raw,true,512,JSON_THROW_ON_ERROR);unlink($p);unlink($p.'.ready');}unlink($barrier);return $out;
}
function test(string $name,callable $fn): void {global $tests,$failed;if(getenv('PISCINA_SKIP_GALERIA')&&str_starts_with($name,'Galeria:'))return;if(getenv('PISCINA_TEST_FILTER')&&!str_contains($name,getenv('PISCINA_TEST_FILTER')))return;$tests++;try{fresh();$fn();foreach(service()->ledger->reconcile() as $kind=>$rows)check(!$rows,'Reconciliação '.$kind.': '.json_encode($rows));echo "PASS $name\n";}catch(Throwable $e){$failed++;echo "FAIL $name: ".$e->getMessage()."\n";}}
test('Aprovação concorrente concede 160000 centavos e uma NFT',function(){$id=pending('Ana');$r=concurrent([['actor'=>1,'action'=>'admin.approve','data'=>['user_id'=>(string)$id]],['actor'=>1,'action'=>'admin.approve','data'=>['user_id'=>(string)$id]]]);check($r[0]['ok']&&$r[1]['ok'],'Ambas retornam concessão única.');assertSame('160000',balance($id,'MR'));assertSame(1,db()->row('SELECT COUNT(*) n FROM nfts WHERE creator_id=?',[$id])['n']);});
test('Depósito concorrente com mesma chave não duplica; conflito de conteúdo',function(){[$u,$n]=user('Ana');$k=testKey();$calls=array_fill(0,2,['actor'=>$u,'action'=>'nft.deposit','data'=>['nft_id'=>(string)$n],'key'=>$k]);$r=concurrent($calls);assertSame($r[0]['data']['operation_id'],$r[1]['data']['operation_id']);assertSame('1000000000',balance($u,'BYC'));assertSame('1',balance($u,'SHARE'));fail(fn()=>op($u,'nft.deposit',['nft_id'=>'999'],$k));});
test('Retirada pública em mR$, cotas independentes e redepósito',function(){[$a,$n]=user('Ana');[$b]=user('Bia');op($a,'nft.deposit',['nft_id'=>(string)$n]);withdraw($b,$n);assertSame('1',balance($a,'SHARE'));assertSame('0',balance($b,'SHARE'));assertSame('20000',balance($b,'MR'));op($b,'nft.deposit',['nft_id'=>(string)$n]);assertSame('1',balance($b,'SHARE'));assertSame('1000000000',balance($b,'BYC'));assertSame(2,db()->row('SELECT COUNT(*) n FROM deposits WHERE nft_id=?',[$n])['n']);});
test('10 BYC não retiram por 11; pagamento único em mR$',function(){[$a,$n]=user('Ana');op($a,'nft.deposit',['nft_id'=>(string)$n]);fail(fn()=>withdraw($a,$n,'BYC'));withdraw($a,$n);assertSame('20000',balance($a,'MR'));assertSame('1000000000',balance($a,'BYC'));assertSame('1',balance($a,'SHARE'));assertSame('PRIVATE',db()->row('SELECT state FROM nfts WHERE id=?',[$n])['state']);});
test('Retiradas concorrentes: somente vencedor paga',function(){[$a,$n]=user('Ana');[$b]=user('Bia');[$c]=user('Caio');op($a,'nft.deposit',['nft_id'=>(string)$n]);$q=service()->quote($b,$n);$payload=['nft_id'=>(string)$n,'payment'=>'MR','parameter_version'=>$q['parameter_version'],'quote_expires'=>$q['quote_expires']];$r=concurrent([['actor'=>$b,'action'=>'nft.withdraw','data'=>$payload],['actor'=>$c,'action'=>'nft.withdraw','data'=>$payload]]);assertSame(1,count(array_filter($r,fn($v)=>$v['ok'])));assertSame('180000',bcadd(balance($b,'MR'),balance($c,'MR'),0));});
test('Venda de 3 BYC por mR$90 sem emissão; segunda aprovação única',function(){[$a,$n]=user('Ana');[$b]=user('Bia');op($a,'nft.deposit',['nft_id'=>(string)$n]);$p=proposal($b,$a,'BYC','3','30.00');assertSame('700000000',balance($a,'BYC'));assertSame('300000000',balance($a,'BYC','reserved'));assertSame('0',balance($b,'BYC'));$k=testKey();$result=op($b,'proposal.approve',['proposal_id'=>$p['proposal_id'],'version'=>'1'],$k);assertSame('SETTLED',$result['state']);assertSame($result['operation_id'],op($b,'proposal.approve',['proposal_id'=>$p['proposal_id'],'version'=>'1'],$k)['operation_id']);assertSame('300000000',balance($b,'BYC'));assertSame('151000',balance($b,'MR'));assertSame('169000',balance($a,'MR'));});
test('Ciclo por BYC custa 1 BYC líquido e não destrói cota',function(){[$a,$n]=user('Ana');[$b,$m]=user('Bia');op($a,'nft.deposit',['nft_id'=>(string)$n]);op($b,'nft.deposit',['nft_id'=>(string)$m]);sale($a,$b,'BYC','1','1.00');withdraw($a,$n,'BYC');assertSame('0',balance($a,'BYC'));assertSame('1',balance($a,'SHARE'));assertSame('1100000000',db()->row("SELECT balance FROM accounts WHERE code='T:BYC:treasury'")['balance']);});
test('Venda de NFT preserva criador, venda de cota não acompanha NFT',function(){[$a,$n]=user('Ana');[$b]=user('Bia');sale($b,$a,'NFT','1','50.00',$n);$row=db()->row('SELECT * FROM nfts WHERE id=?',[$n]);assertSame($a,$row['creator_id']);assertSame($b,$row['owner_id']);op($b,'nft.deposit',['nft_id'=>(string)$n]);sale($a,$b,'SHARE','1','10.00');assertSame('1',balance($a,'SHARE'));assertSame('POOL',db()->row('SELECT state FROM nfts WHERE id=?',[$n])['state']);});
test('Contraproposta libera reservas e invalida versão anterior',function(){[$a,$n]=user('Ana');[$b]=user('Bia');op($a,'nft.deposit',['nft_id'=>(string)$n]);$p=proposal($b,$a,'BYC','3','30.00');$v=op($b,'proposal.revise',['proposal_id'=>$p['proposal_id'],'version'=>'1','asset'=>'BYC','quantity'=>'2','unit_price'=>'20.00','expires_at'=>(new DateTimeImmutable())->modify('+1 hour')->format('c'),'approve'=>true]);assertSame('2',$v['version']);assertSame('0',balance($a,'BYC','reserved'));assertSame('4000',balance($b,'MR','reserved'));fail(fn()=>op($a,'proposal.approve',['proposal_id'=>$p['proposal_id'],'version'=>'1']));op($a,'proposal.approve',['proposal_id'=>$p['proposal_id'],'version'=>'2']);assertSame('200000000',balance($b,'BYC'));});
test('Proposta não reserva patrimônio alheio; saldo reservado não pode gastar',function(){[$a,$n]=user('Ana');[$b,$m]=user('Bia');$p=proposal($a,$b,'NFT','1','1600.00',false,$m);assertSame(null,db()->row('SELECT reserved_proposal FROM nfts WHERE id=?',[$m])['reserved_proposal']);op($a,'proposal.approve',['proposal_id'=>$p['proposal_id'],'version'=>'1']);assertSame('0',balance($a,'MR'));op($b,'nft.deposit',['nft_id'=>(string)$m]);fail(fn()=>withdraw($a,$m));op($a,'proposal.cancel',['proposal_id'=>$p['proposal_id'],'version'=>'1']);assertSame('160000',balance($a,'MR'));});
test('Expiração na ação libera recursos, mesmo antes do cron',function(){[$a,$n]=user('Ana');[$b]=user('Bia');op($a,'nft.deposit',['nft_id'=>(string)$n]);$p=proposal($b,$a,'BYC','3','30.00');db()->run('UPDATE proposal_versions SET expires_at=DATE_SUB(UTC_TIMESTAMP(6),INTERVAL 1 SECOND) WHERE proposal_id=?',[$p['proposal_id']]);$r=op($b,'proposal.approve',['proposal_id'=>$p['proposal_id'],'version'=>'1']);assertSame('EXPIRED',$r['state']);assertSame('1000000000',balance($a,'BYC'));assertSame('0',balance($a,'BYC','reserved'));assertSame(0,service()->expire());});
test('Cancelamento e segunda aprovação concorrentes têm um único desfecho',function(){[$a,$n]=user('Ana');[$b]=user('Bia');op($a,'nft.deposit',['nft_id'=>(string)$n]);$p=proposal($b,$a,'BYC','3','30.00');$r=concurrent([['actor'=>$a,'action'=>'proposal.cancel','data'=>['proposal_id'=>$p['proposal_id'],'version'=>'1']],['actor'=>$b,'action'=>'proposal.approve','data'=>['proposal_id'=>$p['proposal_id'],'version'=>'1']]]);$s=db()->row('SELECT state FROM proposals WHERE id=?',[$p['proposal_id']])['state'];check(in_array($s,['SETTLED','CANCELLED'],true),'Estado terminal único.');assertSame('0',balance($a,'BYC','reserved'));assertSame($s==='SETTLED'?'300000000':'0',balance($b,'BYC'));});
test('Revisão e aprovação concorrentes preservam versão e reservas',function(){[$a,$n]=user('Ana');[$b]=user('Bia');op($a,'nft.deposit',['nft_id'=>(string)$n]);$p=proposal($b,$a,'BYC','3','30.00');concurrent([['actor'=>$a,'action'=>'proposal.revise','data'=>['proposal_id'=>$p['proposal_id'],'version'=>'1','asset'=>'BYC','quantity'=>'2','unit_price'=>'20.00','expires_at'=>(new DateTimeImmutable())->modify('+1 hour')->format('c'),'approve'=>false]],['actor'=>$b,'action'=>'proposal.approve','data'=>['proposal_id'=>$p['proposal_id'],'version'=>'1']]]);$row=db()->row('SELECT * FROM proposals WHERE id=?',[$p['proposal_id']]);check($row['state']==='SETTLED'||$row['current_version']==='2','Revisão ou liquidação exclusiva.');});
test('Dois gastos incompatíveis não criam saldo negativo',function(){[$a,$n]=user('Ana');[$b,$m]=user('Bia');[$c,$z]=user('Caio');$p=proposal($a,$b,'NFT','1','1200.00',true,$m);$q=proposal($a,$c,'NFT','1','1200.00',true,$z);$r=concurrent([['actor'=>$a,'action'=>'proposal.approve','data'=>['proposal_id'=>$p['proposal_id'],'version'=>'1']],['actor'=>$a,'action'=>'proposal.approve','data'=>['proposal_id'=>$q['proposal_id'],'version'=>'1']]]);assertSame(1,count(array_filter($r,fn($v)=>$v['ok'])));assertSame('40000',balance($a,'MR'));});
function distributionFixture(): array {op(1,'admin.parameters',['initial_credit'=>'100000.00','reason'=>'Saldo para cenário de teste']);[$a,$n]=user('Ana');[$b,$m]=user('Bia');[$c]=user('Caio');$nfts=[$n,$m];foreach([1,2]as $i)$nfts[]=(int)op(1,'admin.mint',['user_id'=>(string)$a,'title'=>'Obra '.$i,'reason'=>'Fixture teste'])['nft_id'];foreach([$n,$nfts[2],$nfts[3]]as $x)op($a,'nft.deposit',['nft_id'=>(string)$x]);op($b,'nft.deposit',['nft_id'=>(string)$m]);for($i=0;$i<6;$i++){withdraw($b,$m);op($b,'nft.deposit',['nft_id'=>(string)$m]);}return [$a,$b,$c];}
test('N4 Q10 q3: bruto 240, taxa 100, líquido 140; participante sem cotas',function(){[$a,$b,$c]=distributionFixture();$p=period();assertSame('4',$p['nft_count']);assertSame('10',$p['total_shares']);assertSame('80000',$p['distribution_total']);$r=db()->row('SELECT * FROM rights WHERE user_id=?',[$a]);$f=db()->row('SELECT * FROM fees WHERE user_id=?',[$a]);assertSame('24000',$r['amount']);assertSame('10000',$f['amount']);$before=balance($a,'MR');$k=testKey();$payload=['right_id'=>$r['id']];op($a,'right.accept',$payload,$k);op($a,'right.accept',$payload,$k);op($a,'right.accept',$payload);op($a,'fee.pay',['fee_id'=>$f['id']]);op($a,'fee.pay',['fee_id'=>$f['id']]);assertSame('14000',bcsub(balance($a,'MR'),$before,0));assertSame(null,db()->row('SELECT id FROM rights WHERE user_id=?',[$c]));check(db()->row('SELECT id FROM fees WHERE user_id=?',[$c])!==null,'Taxa mesmo sem cotas.');assertSame(0,service()->periods->capture());});
test('Venda depois do corte não transfere direito, cron atrasado usa snapshot',function(){[$a,$b]=distributionFixture();db()->run('UPDATE parameter_versions SET interval_minutes=1440,first_cutoff=DATE_SUB(UTC_TIMESTAMP(6),INTERVAL 1 SECOND)');sale($b,$a,'SHARE','3','10.00');check(db()->row('SELECT id FROM periods')!==null,'Snapshot capturado antes de vender.');while(service()->periods->processBatch(1)!==null){}assertSame('0',balance($a,'SHARE'));assertSame('24000',db()->row('SELECT amount FROM rights WHERE user_id=?',[$a])['amount']);});
test('Maiores restos: 6667,6667,6666; soma conserva D',function(){op(1,'admin.parameters',['initial_credit'=>'10000.00','reason'=>'Fixture de restos']);[$a,$n]=user('Ana');[$b,$m]=user('Bia');[$c,$z]=user('Caio');foreach([[$a,$n],[$b,$m],[$c,$z]]as[$u,$x])op($u,'nft.deposit',['nft_id'=>(string)$x]);withdraw($a,$m);withdraw($a,$z);period();$r=db()->all('SELECT amount FROM rights ORDER BY user_id');assertSame('6667',$r[0]['amount']);assertSame('6667',$r[1]['amount']);assertSame('6666',$r[2]['amount']);assertSame('20000',array_sum(array_column($r,'amount')));});
test('N=0 Q=0 e taxa com saldo insuficiente permanecem válidos',function(){op(1,'admin.parameters',['initial_credit'=>'0.00','reason'=>'Fixture sem crédito']);[$a]=user('Ana');period();assertSame(0,db()->row('SELECT COUNT(*) n FROM rights')['n']);$f=db()->row('SELECT * FROM fees WHERE user_id=?',[$a]);fail(fn()=>op($a,'fee.pay',['fee_id'=>$f['id']]));assertSame('PENDING',db()->row('SELECT state FROM fees WHERE id=?',[$f['id']])['state']);assertSame('0',balance($a,'MR'));});
test('Parâmetros novos não reescrevem obrigações nem cotação anterior',function(){[$a,$n]=user('Ana');op($a,'nft.deposit',['nft_id'=>(string)$n]);$q=service()->quote($a,$n);period();$f=db()->row('SELECT * FROM fees WHERE user_id=?',[$a]);op(1,'admin.parameters',['admin_fee'=>'200.00','withdraw_money'=>'1500.00','reason'=>'Alteração de teste']);assertSame('10000',db()->row('SELECT amount FROM fees WHERE id=?',[$f['id']])['amount']);fail(fn()=>op($a,'nft.withdraw',['nft_id'=>(string)$n,'payment'=>'MR','parameter_version'=>$q['parameter_version'],'quote_expires'=>$q['quote_expires']]));});
test('Produção não presume política nem data inicial',function(){db()->run('DELETE FROM decision_versions');[$u,$n]=[pending('Ana'),1];fail(fn()=>op(1,'admin.approve',['user_id'=>(string)$u]));assertSame(0,service()->periods->capture());});
test('Precisão decimal, escala mR$, limites e JSON strings',function(){assertSame('160000',Piscina\Exact::units('1600',2));assertSame('1',Piscina\Exact::units('0.00000001',8));assertSame('1',Piscina\Exact::total('50000000','1','BYC'));assertSame('20000',Piscina\Exact::units('200',2));fail(fn()=>Piscina\Exact::units('0.000000001',8),422);fail(fn()=>Piscina\Exact::units('1.1',0),422);fail(fn()=>Piscina\Exact::units('9999999999999999',8),422);fail(fn()=>Piscina\Exact::units(1.6,2),422);});
test('Autorização: cadastro pendente e ativos de terceiros não movimentam',function(){[$a,$n]=user('Ana');[$b]=user('Bia');$c=pending('Caio');fail(fn()=>op($c,'nft.deposit',['nft_id'=>(string)$n]),403);fail(fn()=>op($b,'nft.deposit',['nft_id'=>(string)$n]));fail(fn()=>op($b,'admin.mint',['user_id'=>(string)$b,'title'=>'x','reason'=>'teste']),403);fail(fn()=>proposal($b,$b,'NFT','1','10',true,$n),422);});
test('Retomada de processamento em lotes não publica direitos parciais',function(){distributionFixture();db()->run('UPDATE parameter_versions SET interval_minutes=1440,first_cutoff=DATE_SUB(UTC_TIMESTAMP(6),INTERVAL 1 SECOND)');service()->periods->capture();$batch=service()->periods->processBatch(1);assertSame('PROCESSING',$batch['state']);$r=db()->row('SELECT * FROM rights LIMIT 1');if($r)fail(fn()=>op((int)$r['user_id'],'right.accept',['right_id'=>$r['id']]));while(service()->periods->processBatch(1)!==null){}assertSame(1,db()->row("SELECT COUNT(*) n FROM ledger_transactions WHERE kind='PERIOD_ISSUANCE'")['n']);check(service()->periods->processBatch()===null,'Retomada sem duplicação.');});
test('Períodos atrasados preservam retratos ordenados distintos',function(){[$a,$n]=user('Ana');op($a,'nft.deposit',['nft_id'=>(string)$n]);db()->run('UPDATE parameter_versions SET interval_minutes=15,first_cutoff=DATE_SUB(UTC_TIMESTAMP(6),INTERVAL 16 MINUTE)');assertSame(2,service()->periods->capture());withdraw($a,$n);db()->run('UPDATE parameter_versions SET first_cutoff=DATE_SUB(first_cutoff,INTERVAL 15 MINUTE)'); // somente fixture avança tempo lógico pela data de último corte
 db()->run('UPDATE periods SET cutoff_at=DATE_SUB(cutoff_at,INTERVAL 15 MINUTE)');service()->periods->capture();$rows=db()->all('SELECT nft_count FROM periods ORDER BY cutoff_at');assertSame('1',$rows[0]['nft_count']);assertSame('1',$rows[1]['nft_count']);assertSame('0',$rows[2]['nft_count']);});
test('Reconciliação detecta adulteração de saldo agregado',function(){[$a]=user('Ana');db()->run("UPDATE accounts SET balance=balance+1 WHERE user_id=? AND asset='MR'",[$a]);check(count(service()->ledger->reconcile()['balances'])===1,'Divergência detectada.');db()->run("UPDATE accounts SET balance=balance-1 WHERE user_id=? AND asset='MR'",[$a]);});
test('Transação atravessa corte: eficácia pelo gate e snapshot anterior à próxima alteração',function(){
 [$a,$n]=user('Ana');[$b,$m]=user('Bia');
 db()->run('UPDATE parameter_versions SET interval_minutes=1440,first_cutoff=DATE_ADD(UTC_TIMESTAMP(6),INTERVAL 1 SECOND)');
 db()->pdo->exec('CREATE TRIGGER test_delay BEFORE UPDATE ON nfts FOR EACH ROW DO SLEEP(2)');
 try{$r=concurrent([['actor'=>$a,'action'=>'nft.deposit','data'=>['nft_id'=>(string)$n]],['actor'=>$b,'action'=>'nft.deposit','data'=>['nft_id'=>(string)$m]]]);check($r[0]['ok']&&$r[1]['ok'],'Duas operações válidas.');}
 finally{db()->pdo->exec('DROP TRIGGER test_delay');}
 $p=db()->row('SELECT * FROM periods');assertSame('1',$p['nft_count']);assertSame('1',$p['total_shares']);assertSame(2,db()->row("SELECT COUNT(*) n FROM nfts WHERE state='POOL'")['n']);
});
test('Uploads concorrentes preservam direito único e mesma chave usa hash do conteúdo',function(){
 [$a,$n]=user('Ana');$dir=config()['storage'].'/images';if(!is_dir($dir))mkdir($dir,0700,true);$payloads=[];
 foreach([1,2]as $i){$name=bin2hex(random_bytes(16));$im=imagecreatetruecolor(12,12);imagejpeg($im,$dir.'/'.$name.'.jpg');imagejpeg($im,$dir.'/'.$name.'-thumb.jpg');imagedestroy($im);$payloads[]=['nft_id'=>(string)$n,'image_path'=>$name.'.jpg','thumbnail_path'=>$name.'-thumb.jpg','image_sha'=>hash_file('sha256',$dir.'/'.$name.'.jpg')];}
 $k=testKey();$r=concurrent([['actor'=>$a,'action'=>'nft.image','data'=>$payloads[0],'key'=>$k],['actor'=>$a,'action'=>'nft.image','data'=>$payloads[1],'key'=>$k]]);check($r[0]['ok']&&$r[1]['ok'],'Idempotência pelo conteúdo.');assertSame($r[0]['data']['operation_id'],$r[1]['data']['operation_id']);
 [$b]=user('Bia');sale($b,$a,'NFT','1','10.00',$n);fail(fn()=>op($b,'nft.image',$payloads[0]));fail(fn()=>op($a,'nft.image',$payloads[1]));
 $row=db()->row('SELECT image_path FROM nfts WHERE id=?',[$n]);check(is_file($dir.'/'.$row['image_path']),'Arquivo associado existe.');
});
test('Falha de imagem não consome envio; somente criador autorizado',function(){[$a,$n]=user('Ana');[$b]=user('Bia');$payload=['nft_id'=>(string)$n,'image_path'=>str_repeat('a',32).'.jpg','thumbnail_path'=>str_repeat('a',32).'-thumb.jpg','image_sha'=>str_repeat('a',64)];fail(fn()=>op($a,'nft.image',$payload));assertSame(null,db()->row('SELECT image_path FROM nfts WHERE id=?',[$n])['image_path']);fail(fn()=>op($b,'nft.image',$payload));});
test('Tokens de e-mail e recuperação expiram, uso único e senha revoga sessões',function(){
 $auth=new Piscina\Auth(db(),config());$r=$auth->register(['email'=>'teste@local.invalid','display_name'=>'Teste','password'=>'senha-nova-local']);$u=(int)$r['user_id'];
 $body=db()->row('SELECT body FROM outbox ORDER BY id DESC LIMIT 1')['body'];preg_match('/#verify=([a-f0-9]{64})/',$body,$m);$auth->useToken(['token'=>$m[1]],'verify');fail(fn()=>$auth->useToken(['token'=>$m[1]],'verify'),422);
 op(1,'admin.approve',['user_id'=>(string)$u]);$auth->requestToken(['email'=>'teste@local.invalid'],'reset');$body=db()->row('SELECT body FROM outbox ORDER BY id DESC LIMIT 1')['body'];preg_match('/#reset=([a-f0-9]{64})/',$body,$m);$auth->useToken(['token'=>$m[1],'password'=>'senha-redefinida-local'],'reset');assertSame('2',db()->row('SELECT auth_version FROM users WHERE id=?',[$u])['auth_version']);check(password_verify('senha-redefinida-local',db()->row('SELECT password_hash FROM users WHERE id=?',[$u])['password_hash']),'Senha redefinida.');
 fail(fn()=>$auth->useToken(['token'=>$m[1],'password'=>'senha-outra-local'],'reset'),422);
 $auth->requestToken(['email'=>'teste@local.invalid'],'reset');$body=db()->row('SELECT body FROM outbox ORDER BY id DESC LIMIT 1')['body'];preg_match('/#reset=([a-f0-9]{64})/',$body,$m);db()->run('UPDATE auth_tokens SET expires_at=DATE_SUB(UTC_TIMESTAMP(6),INTERVAL 1 SECOND)');fail(fn()=>$auth->useToken(['token'=>$m[1],'password'=>'senha-outra-local'],'reset'),422);
});
test('Anúncio não liquida nem reserva; cancelamento remove publicação',function(){[$a,$n]=user('Ana');$r=op($a,'listing.create',['side'=>'SELL','asset'=>'NFT','nft_id'=>(string)$n,'quantity'=>'1','unit_price'=>'0.00','expires_at'=>(new DateTimeImmutable())->modify('+1 hour')->format('c')]);assertSame(null,db()->row('SELECT reserved_proposal FROM nfts WHERE id=?',[$n])['reserved_proposal']);op($a,'listing.cancel',['listing_id'=>$r['listing_id']]);assertSame('CANCELLED',db()->row('SELECT state FROM listings WHERE id=?',[$r['listing_id']])['state']);});
test('Preço zero ou fração com total zero mantém entrega e não cria pagamento fictício',function(){[$a,$n]=user('Ana');[$b]=user('Bia');op($a,'nft.deposit',['nft_id'=>(string)$n]);sale($b,$a,'BYC','0.00000001','0.01');assertSame('1',balance($b,'BYC'));assertSame('160000',balance($b,'MR'));sale($b,$a,'SHARE','1','0.00');assertSame('1',balance($b,'SHARE'));});
test('Deadlock MySQL real faz rollback e tentativa limitada sem duplicar efeitos',function(){
 db()->pdo->exec('CREATE TABLE retry_fixture(id INT PRIMARY KEY,value INT NOT NULL) ENGINE=InnoDB');db()->run('INSERT INTO retry_fixture VALUES(1,0),(2,0)');$dir=config()['storage'].'/tmp';if(!is_dir($dir))mkdir($dir,0700,true);$marker=$dir.'/'.testKey();
 $r=concurrent([['actor'=>1,'action'=>'test.deadlock','data'=>['first'=>1,'marker'=>$marker]],['actor'=>1,'action'=>'test.deadlock','data'=>['first'=>2,'marker'=>$marker]]]);check($r[0]['ok']&&$r[1]['ok'],'Transações retomadas.');check(max($r[0]['data']['attempts'],$r[1]['data']['attempts'])>1,'Houve deadlock e retry.');foreach(db()->all('SELECT value FROM retry_fixture')as $row)assertSame('2',$row['value']);unlink($marker.'.1');unlink($marker.'.2');
});
test('Cron recupera calendário longo por lotes; operação não ultrapassa cortes pendentes',function(){
 [$a,$n]=user('Ana');db()->run('UPDATE parameter_versions SET interval_minutes=1440,first_cutoff=DATE_SUB(DATE_SUB(UTC_TIMESTAMP(6),INTERVAL 31 DAY),INTERVAL 1 SECOND)');assertSame(10,service()->periods->capture());fail(fn()=>op($a,'nft.deposit',['nft_id'=>(string)$n]),503);assertSame('PRIVATE',db()->row('SELECT state FROM nfts WHERE id=?',[$n])['state']);assertSame(10,db()->row('SELECT COUNT(*) n FROM periods')['n']);assertSame(10,service()->periods->capture());assertSame(10,service()->periods->capture());assertSame(2,service()->periods->capture());assertSame(0,service()->periods->capture());op($a,'nft.deposit',['nft_id'=>(string)$n]);assertSame(32,db()->row('SELECT COUNT(*) n FROM periods')['n']);
});
test('Gasto novo libera reserva vencida do autor antes de validar saldo',function(){
 [$a,$n]=user('Ana');[$b,$m]=user('Bia');$p=proposal($a,$b,'NFT','1','1600.00',false,$m);op($a,'proposal.approve',['proposal_id'=>$p['proposal_id'],'version'=>'1']);db()->run('UPDATE proposal_versions SET expires_at=DATE_SUB(UTC_TIMESTAMP(6),INTERVAL 1 SECOND) WHERE proposal_id=?',[$p['proposal_id']]);op($b,'nft.deposit',['nft_id'=>(string)$m]);withdraw($a,$m);assertSame('20000',balance($a,'MR'));assertSame('0',balance($a,'MR','reserved'));assertSame('EXPIRED',db()->row('SELECT state FROM proposals WHERE id=?',[$p['proposal_id']])['state']);
});
test('Aprovação sem e-mail exige admin, motivo e confirmação; não falsifica verificação',function(){
 $u=pending('SemEmail');db()->run('UPDATE users SET email_verified_at=NULL WHERE id=?',[$u]);[$other]=user('Outro');
 $payload=['user_id'=>(string)$u,'confirm_without_email'=>true,'reason'=>'Aprovação presencial do participante'];
 fail(fn()=>op($other,'admin.approve_without_email',$payload),403);
 fail(fn()=>op(1,'admin.approve',['user_id'=>(string)$u]));
 fail(fn()=>op(1,'admin.approve_without_email',['user_id'=>(string)$u,'reason'=>'Motivo válido']),422);
 fail(fn()=>op(1,'admin.approve_without_email',['user_id'=>(string)$u,'confirm_without_email'=>true,'reason'=>'   ']),422);
 fail(fn()=>op(1,'admin.approve_without_email',['user_id'=>(string)$u,'confirm_without_email'=>'true','reason'=>'Motivo válido']),422);
 assertSame('pending',service()->user($u)['status']);assertSame('0',balance($u,'MR'));
 $key=testKey();$r=op(1,'admin.approve_without_email',$payload,$key);assertSame(true,$r['email_verification_bypassed']);
 assertSame($r['operation_id'],op(1,'admin.approve_without_email',$payload,$key)['operation_id']);
 op(1,'admin.approve_without_email',$payload);
 assertSame('approved',service()->user($u)['status']);assertSame(null,service()->user($u)['email_verified_at']);
 assertSame('160000',balance($u,'MR'));assertSame('0',balance($u,'BYC'));assertSame('0',balance($u,'SHARE'));
 assertSame(1,db()->row('SELECT COUNT(*) n FROM nfts WHERE creator_id=?',[$u])['n']);
 assertSame(1,db()->row('SELECT COUNT(*) n FROM initial_grants WHERE user_id=?',[$u])['n']);
 $audit=db()->row('SELECT actor_id,kind,data FROM audit_events WHERE operation_id=?',[$r['operation_id']]);
 assertSame(1,$audit['actor_id']);assertSame('admin.approve_without_email',$audit['kind']);
 $data=json_decode($audit['data'],true);assertSame($payload['reason'],$data['input']['reason']);check($data['result']['email_verification_bypassed'],'Exceção auditada.');
});
test('Aprovação excepcional concorrente concede uma única carteira e NFT',function(){
 $u=pending('Concorrente');db()->run('UPDATE users SET email_verified_at=NULL WHERE id=?',[$u]);
 $data=['user_id'=>(string)$u,'confirm_without_email'=>true,'reason'=>'Confirmação manual pelo administrador'];
 $r=concurrent([['actor'=>1,'action'=>'admin.approve_without_email','data'=>$data],['actor'=>1,'action'=>'admin.approve_without_email','data'=>$data]]);
 check($r[0]['ok']&&$r[1]['ok'],'Ambas concluem sem duplicar concessão.');assertSame('160000',balance($u,'MR'));
 assertSame(1,db()->row('SELECT COUNT(*) n FROM nfts WHERE creator_id=?',[$u])['n']);assertSame(null,service()->user($u)['email_verified_at']);
});
test('Aprovação excepcional respeita limites e rollback da concessão',function(){
 $u=pending('Limitado');db()->run('UPDATE users SET email_verified_at=NULL WHERE id=?',[$u]);
 $data=['user_id'=>(string)$u,'confirm_without_email'=>true,'reason'=>'Verificação presencial documentada'];
 $limited=new Piscina\Domain(db(),array_replace(config(),['max_users'=>0]));
 fail(fn()=>$limited->operation(1,'admin.approve_without_email',$data,testKey()));
 $limited=new Piscina\Domain(db(),array_replace(config(),['max_nfts'=>0]));
 fail(fn()=>$limited->operation(1,'admin.approve_without_email',$data,testKey()));
 assertSame('pending',service()->user($u)['status']);assertSame('0',balance($u,'MR'));
 assertSame(0,db()->row('SELECT COUNT(*) n FROM initial_grants WHERE user_id=?',[$u])['n']);
 assertSame(0,db()->row("SELECT COUNT(*) n FROM operations WHERE action='admin.approve_without_email'")['n']);
});
test('Reaprovação de concessão anterior preserva gastos, cotas e NFT',function(){
 [$u,$n]=user('Anterior');op($u,'nft.deposit',['nft_id'=>(string)$n]);withdraw($u,$n);
 db()->run("UPDATE users SET status='pending',email_verified_at=NULL WHERE id=?",[$u]);
 $r=op(1,'admin.approve_without_email',['user_id'=>(string)$u,'confirm_without_email'=>true,'reason'=>'Reaprovação após ajuste cadastral']);
 assertSame(true,$r['already_granted']);assertSame('approved',service()->user($u)['status']);
 assertSame('20000',balance($u,'MR'));assertSame('1000000000',balance($u,'BYC'));assertSame('1',balance($u,'SHARE'));
 assertSame(1,db()->row('SELECT COUNT(*) n FROM nfts WHERE creator_id=?',[$u])['n']);
});
test('Carteiras administrativas negam participantes e não vazam para perfil público',function(){
 [$a,$n]=user('Ana');[$b]=user('Bia');op($a,'nft.deposit',['nft_id'=>(string)$n]);$p=proposal($b,$a,'BYC','3','30.00');
 $q=new Piscina\Queries(service());fail(fn()=>$q->admin($a,[]),403);fail(fn()=>$q->adminWallet($a,['user_id'=>(string)$b]),403);
 $before=db()->row('SELECT COUNT(*) n FROM accounts')['n'];$d=$q->admin(1,['q'=>(string)$a]);
 assertSame(1,count($d['users']));assertSame('700000000',$d['users'][0]['balances']['BYC']['available']);
 assertSame('300000000',$d['users'][0]['balances']['BYC']['reserved']);assertSame('1',$d['users'][0]['custody']['pool_deposits']);
 $wallet=$q->adminWallet(1,['user_id'=>(string)$a]);assertSame($a,$wallet['user']['id']);
 assertSame('300000000',$wallet['balances']['BYC']['reserved']);check(count($wallet['history'])>0,'Extrato disponível.');
 check(!array_key_exists('password_hash',$wallet['user']),'Senha não exposta.');
 $public=$q->profile($a);check(!array_key_exists('balances',$public)&&!array_key_exists('email',$public),'Perfil público preservado.');
 assertSame($before,db()->row('SELECT COUNT(*) n FROM accounts')['n']);
 op($a,'proposal.cancel',['proposal_id'=>$p['proposal_id'],'version'=>'1']);
});
test('Busca administrativa literal e paginação alcançam todos os cadastros sem criar contas',function(){
 $q=new Piscina\Queries(service());$special=pending('Literal%_Teste');
 for($i=0;$i<30;$i++)db()->run('INSERT INTO users(email,password_hash,display_name,created_at) VALUES(?,?,?,UTC_TIMESTAMP(6))',['pagina'.$i.'@local.invalid','hash-fixture','Pagina '.$i]);
 $before=db()->row('SELECT COUNT(*) n FROM accounts')['n'];$first=$q->admin(1,['q'=>'pagina']);$second=$q->admin(1,['q'=>'pagina','offset'=>24]);
 assertSame('30',$first['users_total']);assertSame(24,count($first['users']));check($first['has_more'],'Mais resultados disponíveis.');assertSame(6,count($second['users']));check(!$second['has_more'],'Última página.');
 assertSame(30,count(array_unique(array_column(array_merge($first['users'],$second['users']),'id'))));
 $literal=$q->admin(1,['q'=>'%_']);assertSame(1,count($literal['users']));assertSame($special,$literal['users'][0]['id']);
 $byEmail=$q->admin(1,['q'=>'pagina29@local.invalid']);assertSame(1,count($byEmail['users']));
 $approved=$q->admin(1,['status'=>'approved']);assertSame('0',$approved['users_total']);
 assertSame('0',$first['users'][0]['balances']['MR']['available']);assertSame($before,db()->row('SELECT COUNT(*) n FROM accounts')['n']);
 fail(fn()=>$q->admin(1,['status'=>'arbitrario']),422);
});
test('Extrato administrativo paginado e custódia contam apenas o último depositante',function(){
 op(1,'admin.parameters',['initial_credit'=>'100000.00','reason'=>'Fixture para extrato paginado']);[$a,$n]=user('Ana');[$b]=user('Bia');
 for($i=0;$i<9;$i++){op($a,'nft.deposit',['nft_id'=>(string)$n]);withdraw($a,$n);}
 $q=new Piscina\Queries(service());$one=$q->adminWallet(1,['user_id'=>(string)$a]);$two=$q->adminWallet(1,['user_id'=>(string)$a,'offset'=>24]);
 assertSame(24,count($one['history']));check($one['has_more'],'Há histórico anterior.');assertSame(4,count($two['history']));check(!$two['has_more'],'Fim do histórico.');
 assertSame(28,count(array_unique(array_column(array_merge($one['history'],$two['history']),'entry_id'))));
 assertSame('1',$one['custody']['private_nfts']);assertSame('0',$one['custody']['pool_deposits']);
 op($a,'nft.deposit',['nft_id'=>(string)$n]);withdraw($b,$n);op($b,'nft.deposit',['nft_id'=>(string)$n]);
 assertSame('0',$q->adminWallet(1,['user_id'=>(string)$a])['custody']['pool_deposits']);
 assertSame('1',$q->adminWallet(1,['user_id'=>(string)$b])['custody']['pool_deposits']);
 fail(fn()=>$q->adminWallet(1,['user_id'=>'999999']),404);
});
function adminImageData(int $nft,?string $version=null): array {
 $n=db()->row('SELECT * FROM nfts WHERE id=?',[$nft]);$dir=config()['storage'].'/images';if(!is_dir($dir))mkdir($dir,0700,true);
 $name=bin2hex(random_bytes(16));$im=imagecreatetruecolor(12,10);imagefill($im,0,0,imagecolorallocate($im,80,150,100));
 imagejpeg($im,$dir.'/'.$name.'.jpg');imagejpeg($im,$dir.'/'.$name.'-thumb.jpg');imagedestroy($im);
 return ['nft_id'=>(string)$nft,'confirm'=>true,'reason'=>'Correção administrativa da imagem da obra',
  'expected_version'=>$version??Piscina\NftImage::editVersion($n),'image_path'=>$name.'.jpg','thumbnail_path'=>$name.'-thumb.jpg',
  'image_sha'=>hash_file('sha256',$dir.'/'.$name.'.jpg')];
}
test('Troca administrativa substitui somente imagem/miniatura, com auditoria e proveniência',function(){
 [$u,$n]=user('Ana');$original=adminImageData($n);op($u,'nft.image',$original);
 $before=db()->row('SELECT * FROM nfts WHERE id=?',[$n]);$balances=service()->ledger->balances($u);$entries=db()->row('SELECT COUNT(*) n FROM ledger_entries')['n'];
 $data=adminImageData($n);$r=op(1,'admin.nft.image_replace',$data);
 $after=db()->row('SELECT * FROM nfts WHERE id=?',[$n]);
 foreach(['id','creator_id','owner_id','title','state','reserved_proposal','created_at'] as $key)assertSame($before[$key],$after[$key],$key);
 assertSame($data['image_path'],$after['image_path']);assertSame($data['thumbnail_path'],$after['thumbnail_path']);
 assertSame(json_encode($balances),json_encode(service()->ledger->balances($u)));assertSame($entries,db()->row('SELECT COUNT(*) n FROM ledger_entries')['n']);
 assertSame($before['image_path'],$r['previous']['image_path']);check($r['previous']['version']!==$r['current']['version'],'Versão muda.');
 $audit=db()->row('SELECT * FROM audit_events WHERE operation_id=?',[$r['operation_id']]);assertSame(1,$audit['actor_id']);
 assertSame('admin.nft.image_replace',$audit['kind']);$body=json_decode($audit['data'],true);
 assertSame($data['reason'],$body['input']['reason']);assertSame($before['image_path'],$body['result']['previous']['image_path']);
 assertSame('IMAGE_REPLACED',db()->row('SELECT kind FROM nft_events WHERE nft_id=? ORDER BY id DESC LIMIT 1',[$n])['kind']);
 $q=new Piscina\Queries(service());$admin=$q->adminNft(1,['nft_id'=>(string)$n]);$public=$q->nft($n);
 assertSame(Piscina\NftImage::version($after),$public['image_version']);assertSame(Piscina\NftImage::editVersion($after),$admin['edit_version']);
 check(!isset($public['edit_version'],$public['image_path']),'Consulta pública sem token administrativo ou caminhos.');
});
test('Troca de imagem é exclusiva de admin; mantém envio único do criador',function(){
 [$u,$n]=user('Ana');[$other]=user('Bia');$data=adminImageData($n);
 fail(fn()=>op($u,'admin.nft.image_replace',$data),403);fail(fn()=>op($other,'admin.nft.image_replace',$data),403);
 $q=new Piscina\Queries(service());fail(fn()=>$q->adminNft($u,['nft_id'=>(string)$n]),403);
 $r=op(1,'admin.nft.image_replace',$data);$after=adminImageData($n);
 fail(fn()=>op($u,'nft.image',$after));assertSame($data['image_path'],db()->row('SELECT image_path FROM nfts WHERE id=?',[$n])['image_path']);
});
test('Troca administrativa exige motivo, confirmação, versão e par JPEG válido',function(){
 [$u,$n]=user('Ana');$data=adminImageData($n);$old=db()->row('SELECT * FROM nfts WHERE id=?',[$n]);
 fail(fn()=>op(1,'admin.nft.image_replace',array_replace($data,['reason'=>'x'])),422);
 fail(fn()=>op(1,'admin.nft.image_replace',array_replace($data,['reason'=>['invalido']])),422);
 fail(fn()=>op(1,'admin.nft.image_replace',array_replace($data,['confirm'=>false])),422);
 fail(fn()=>op(1,'admin.nft.image_replace',array_replace($data,['expected_version'=>str_repeat('0',64)])));
 fail(fn()=>op(1,'admin.nft.image_replace',array_replace($data,['thumbnail_path'=>'../../fora.jpg'])),422);
 fail(fn()=>op(1,'admin.nft.image_replace',array_replace($data,['image_sha'=>'invalid'])),422);
 unlink(config()['storage'].'/images/'.$data['thumbnail_path']);fail(fn()=>op(1,'admin.nft.image_replace',$data));
 assertSame(json_encode($old),json_encode(db()->row('SELECT * FROM nfts WHERE id=?',[$n])));
 assertSame(0,db()->row("SELECT COUNT(*) n FROM operations WHERE action='admin.nft.image_replace'")['n']);
});
test('Troca bloqueada para NFT reservada e para custódia alterada desde a consulta',function(){
 [$a,$n]=user('Ana');[$b]=user('Bia');$old=adminImageData($n);$p=proposal($b,$a,'NFT','1','10.00',true,$n);
 fail(fn()=>op(1,'admin.nft.image_replace',$old));op($a,'proposal.cancel',['proposal_id'=>$p['proposal_id'],'version'=>'1']);
 sale($b,$a,'NFT','1','10.00',$n);fail(fn()=>op(1,'admin.nft.image_replace',$old));
 $fresh=adminImageData($n);op(1,'admin.nft.image_replace',$fresh);assertSame($b,db()->row('SELECT owner_id FROM nfts WHERE id=?',[$n])['owner_id']);
});
test('Duas trocas simultâneas com a mesma versão têm um vencedor',function(){
 [$u,$n]=user('Ana');$one=adminImageData($n);$two=adminImageData($n);
 $r=concurrent([['actor'=>1,'action'=>'admin.nft.image_replace','data'=>$one],['actor'=>1,'action'=>'admin.nft.image_replace','data'=>$two]]);
 assertSame(1,count(array_filter($r,fn($v)=>$v['ok'])));
 assertSame(1,db()->row("SELECT COUNT(*) n FROM nft_events WHERE kind='IMAGE_REPLACED'")['n']);
 assertSame(1,db()->row("SELECT COUNT(*) n FROM audit_events WHERE kind='admin.nft.image_replace'")['n']);
});
test('Replay da troca não duplica evento e chave diferente com versão antiga falha',function(){
 [$u,$n]=user('Ana');$data=adminImageData($n);$key=testKey();$r=op(1,'admin.nft.image_replace',$data,$key);
 $retry=adminImageData($n,$data['expected_version']);$retry['image_sha']=$data['image_sha'];
 assertSame($r['operation_id'],op(1,'admin.nft.image_replace',$retry,$key)['operation_id']);
 fail(fn()=>op(1,'admin.nft.image_replace',$retry));
 fail(fn()=>op(1,'admin.nft.image_replace',array_replace($data,['reason'=>'Outro motivo documentado']),$key));
 assertSame(1,db()->row("SELECT COUNT(*) n FROM nft_events WHERE kind='IMAGE_REPLACED'")['n']);
});
test('Cron preserva versões auditadas e remove somente órfãos antigos',function(){
 [$u,$n]=user('Ana');$old=adminImageData($n);op($u,'nft.image',$old);$data=adminImageData($n);op(1,'admin.nft.image_replace',$data);
 $orphan=adminImageData($n);$dir=config()['storage'].'/images';
 foreach([$old,$data,$orphan] as $set)foreach(['image_path','thumbnail_path'] as $key)touch($dir.'/'.$set[$key],time()-172800);
 (new Piscina\Upload(service(),config()))->cleanup();
 foreach([$old,$data] as $set)foreach(['image_path','thumbnail_path'] as $key)check(is_file($dir.'/'.$set[$key]),'Versão auditada preservada.');
 check(!is_file($dir.'/'.$orphan['image_path'])&&!is_file($dir.'/'.$orphan['thumbnail_path']),'Órfãos removidos.');
});
test('Troca em NFT na piscina não altera economia nem captura calendário atrasado',function(){
 [$u,$n]=user('Ana');op($u,'nft.deposit',['nft_id'=>(string)$n]);$data=adminImageData($n);$balances=service()->ledger->balances($u);
 db()->run('UPDATE parameter_versions SET interval_minutes=1440,first_cutoff=DATE_SUB(UTC_TIMESTAMP(6),INTERVAL 40 DAY)');
 $r=op(1,'admin.nft.image_replace',$data);assertSame(null,$r['owner_id']);assertSame('POOL',$r['state']);
 assertSame(json_encode($balances),json_encode(service()->ledger->balances($u)));
 assertSame(0,db()->row('SELECT COUNT(*) n FROM periods')['n']);
});
require __DIR__.'/danger-domain.php';
require __DIR__.'/galeria-domain.php';
echo "\n$tests cenários, $failed falhas. MySQL ".db()->row('SELECT VERSION() v')['v'].', PHP '.PHP_VERSION."\n";exit($failed?1:0);
