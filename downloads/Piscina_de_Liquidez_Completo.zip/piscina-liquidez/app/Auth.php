<?php
declare(strict_types=1);
namespace Piscina;
final class Auth {
    public function __construct(private Database $db,private array $config) {}
    public function session(): void {
        if(session_status()===PHP_SESSION_ACTIVE) return;
        $dir=$this->config['session_path'];if(!is_dir($dir)&&!mkdir($dir,0700,true)) throw new \RuntimeException('Armazenamento de sessão indisponível.');
        ini_set('session.use_strict_mode','1');ini_set('session.use_only_cookies','1');ini_set('session.save_path',$dir);
        session_name('piscina_session');session_set_cookie_params(['lifetime'=>0,'path'=>($this->config['base_path']??'').'/' ,'secure'=>$this->config['secure_cookie'],'httponly'=>true,'samesite'=>'Lax']);session_start();
        $_SESSION['csrf']??=bin2hex(random_bytes(32));
        if(isset($_SESSION['user_id'])&&time()-($_SESSION['last_seen']??0)>3600) {$this->logout();return;}
        $_SESSION['last_seen']=time();
    }
    public function csrf(): string {$this->session();return $_SESSION['csrf'];}
    public function actor(): int {$this->session();if(empty($_SESSION['user_id'])) throw new Problem('Entre para continuar.',401,'unauthenticated');$u=$this->db->row('SELECT auth_version FROM users WHERE id=?',[$_SESSION['user_id']]);if(!$u||(int)$u['auth_version']!==($_SESSION['auth_version']??0)) {$this->logout();throw new Problem('Sessão encerrada. Entre novamente.',401);}Restrictions::check($this->db,(int)$_SESSION['user_id']);return (int)$_SESSION['user_id'];}
    public function checkCsrf(?string $token): void {$this->session();if(!$token||!hash_equals($_SESSION['csrf'],$token)) throw new Problem('Sessão da página expirou. Atualize e tente novamente.',403,'csrf');}
    public function limit(string $kind,string $identity,int $max=10,int $seconds=900): void {
        if($max<1||$max>1000000||$seconds<1||$seconds>86400) throw new \InvalidArgumentException('Limite de tentativas inválido.');
        $bucket=hash('sha256',$kind.':'.$identity);
        $allowed=$this->db->transaction(function() use($bucket,$max,$seconds){
            // O upsert obtém bloqueio exclusivo diretamente, sem converter o
            // bloqueio compartilhado de INSERT IGNORE em SELECT FOR UPDATE.
            // A ordem das atribuições preserva a janela antiga ao contar.
            $this->db->run('INSERT INTO rate_limits(bucket,attempts,expires_at) VALUES(?,1,DATE_ADD(UTC_TIMESTAMP(6),INTERVAL ? SECOND))
                ON DUPLICATE KEY UPDATE
                attempts=IF(expires_at<=UTC_TIMESTAMP(6),1,LEAST(attempts+1,?)),
                expires_at=IF(expires_at<=UTC_TIMESTAMP(6),DATE_ADD(UTC_TIMESTAMP(6),INTERVAL ? SECOND),expires_at)',[$bucket,$seconds,$max+1,$seconds]);
            // A transação ainda detém o bloqueio da escrita: cada chamada lê
            // sua própria contagem, inclusive quando precisa responder 429.
            return (int)$this->db->row('SELECT attempts FROM rate_limits WHERE bucket=?',[$bucket])['attempts']<=$max;
        });if(!$allowed) throw new Problem('Muitas tentativas. Aguarde alguns minutos.',429,'rate_limit');
    }
    private function registrationLimits(): array {
        $configured=$this->config['registration_limits']??[];
        if(!is_array($configured)) throw new \RuntimeException('Configuração de limites de cadastro inválida.');
        $limits=[];
        foreach(['per_ip'=>[50,500],'per_email'=>[3,10],'global'=>[100,1000]] as $key=>[$default,$maximum]) {
            $value=$configured[$key]??$default;
            if(!is_int($value)||$value<1||$value>$maximum) throw new \RuntimeException('Limite de cadastro inválido: '.$key);
            $limits[$key]=$value;
        }
        return $limits;
    }
    public function register(array $d): array {
        $email=mb_strtolower(trim((string)($d['email']??'')));$name=trim((string)($d['display_name']??''));$password=(string)($d['password']??'');
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($email)>190) throw new Problem('E-mail inválido.');
        if(mb_strlen($name)<2||mb_strlen($name)>80) throw new Problem('Identificação pública entre 2 e 80 caracteres.');$this->password($password);
        $limits=$this->registrationLimits();
        // Bloqueios de origem/e-mail não gastam a cota global. A origem é
        // limitada antes de criar contadores de novos endereços de e-mail.
        $this->limit('register',$_SERVER['REMOTE_ADDR']??'cli',$limits['per_ip']);
        $this->limit('register.email',$email,$limits['per_email']);
        $this->limit('register.global','all',$limits['global']);
        return $this->db->transaction(function() use($email,$name,$password){
            if($this->db->row('SELECT id FROM users WHERE email=?',[$email])) throw new Problem('Não foi possível cadastrar esse e-mail.',409);
            try {$this->db->run('INSERT INTO users(email,password_hash,display_name,created_at) VALUES(?,?,?,UTC_TIMESTAMP(6))',[$email,password_hash($password,PASSWORD_DEFAULT),$name]);}
            catch(\PDOException $e) {if((int)($e->errorInfo[1]??0)===1062) throw new Problem('Não foi possível cadastrar esse e-mail.',409);throw $e;}
            $id=(int)$this->db->pdo->lastInsertId();$this->token($id,'verify');return ['user_id'=>(string)$id,'message'=>'Cadastro criado. Verifique seu e-mail para solicitar aprovação.'];
        });
    }
    private function password(string $p): void {if(strlen($p)<12||strlen($p)>72) throw new Problem('Senha deve ter entre 12 e 72 bytes.');}
    public function login(array $d): array {
        $email=mb_strtolower(trim((string)($d['email']??'')));$this->limit('login',($_SERVER['REMOTE_ADDR']??'cli').':'.$email);
        $u=$this->db->row('SELECT * FROM users WHERE email=?',[$email]);
        $hash=$u['password_hash']??'$2y$10$5pgmi6DdRFXLFVoMVHLBeujbaJ6ri/BGLNpGwNUPlNUYaiojaNCGO';
        if(!password_verify((string)($d['password']??''),$hash)||!$u) throw new Problem('E-mail ou senha incorretos.',401);
        $rehash=password_needs_rehash($u['password_hash'],PASSWORD_DEFAULT)?password_hash($d['password'],PASSWORD_DEFAULT):null;
        return $this->db->transaction(function()use($u,$rehash){
            $this->db->row('SELECT id FROM economic_gate WHERE id=1 FOR UPDATE');
            $fresh=$this->db->row('SELECT * FROM users WHERE id=?',[$u['id']]);
            if(!$fresh||!hash_equals($u['password_hash'],$fresh['password_hash']))throw new Problem('Credenciais alteradas. Entre novamente.',401);
            Restrictions::check($this->db,(int)$u['id']);
            if($rehash)$this->db->run('UPDATE users SET password_hash=? WHERE id=?',[$rehash,$u['id']]);
            $this->session();session_regenerate_id(true);$_SESSION['user_id']=(int)$u['id'];$_SESSION['auth_version']=(int)$fresh['auth_version'];$_SESSION['csrf']=bin2hex(random_bytes(32));$_SESSION['last_seen']=time();
            return ['user'=>['id'=>$u['id'],'display_name'=>$u['display_name'],'status'=>$u['status'],'role'=>$u['role']],'csrf'=>$_SESSION['csrf']];
        });
    }
    public function logout(): array {
        $this->session();$_SESSION=[];session_regenerate_id(true);$_SESSION['csrf']=bin2hex(random_bytes(32));$_SESSION['last_seen']=time();return ['csrf'=>$_SESSION['csrf'],'logged_out'=>true];
    }
    public function reauthenticate(int $actor,string $password): void {$this->limit('reauth',(string)$actor,10);$u=$this->db->row('SELECT password_hash FROM users WHERE id=?',[$actor]);if(!$u||!password_verify($password,$u['password_hash'])) throw new Problem('Confirme sua senha atual.',403);}
    public function requestToken(array $d,string $kind): array {
        $email=mb_strtolower(trim((string)($d['email']??'')));$this->limit('token',($_SERVER['REMOTE_ADDR']??'cli').':'.$email,4);
        $this->db->transaction(function() use($email,$kind){$this->db->row('SELECT id FROM economic_gate WHERE id=1 FOR UPDATE');$u=$this->db->row('SELECT u.id,u.email_verified_at FROM users u LEFT JOIN admin_restrictions r ON r.user_id=u.id WHERE u.email=? AND r.deleted_at IS NULL',[$email]);if($u&&($kind!=='verify'||!$u['email_verified_at'])) $this->token((int)$u['id'],$kind);});
        return ['message'=>'Se o endereço for elegível, enviaremos as instruções.'];
    }
    private function token(int $id,string $kind): void {
        $token=bin2hex(random_bytes(32));$expires=(new \DateTimeImmutable($this->db->now()))->modify($kind==='reset'?'+1 hour':'+24 hours')->format('Y-m-d H:i:s.u');
        $this->db->run('INSERT INTO auth_tokens(user_id,kind,token_hash,expires_at) VALUES(?,?,?,?)',[$id,$kind,hash('sha256',$token),$expires]);
        // Fragmento não chega a logs de URL; frontend o troca por POST e remove da barra.
        $link=rtrim($this->config['url'],'/').($this->config['base_path']??'').'/index.php#'.$kind.'='.$token;
        $this->db->run('INSERT INTO outbox(user_id,subject,body,next_attempt_at) VALUES(?,?,?,UTC_TIMESTAMP(6))',[$id,$kind==='verify'?'Verifique seu e-mail':'Redefina sua senha',"Piscina de Liquidez\n\nAbra: $link\n\nLink de uso único, com validade limitada.\nMoeda de simulação, sem conversão para dinheiro real."]);
    }
    public function useToken(array $d,string $kind): array {
        $token=(string)($d['token']??'');if(!preg_match('/^[a-f0-9]{64}$/D',$token)) throw new Problem('Link inválido ou expirado.');
        $password=(string)($d['password']??'');if($kind==='reset') $this->password($password);
        return $this->db->transaction(function() use($token,$kind,$password){
            $this->db->row('SELECT id FROM economic_gate WHERE id=1 FOR UPDATE');
            $t=$this->db->row('SELECT * FROM auth_tokens WHERE token_hash=? AND kind=? FOR UPDATE',[hash('sha256',$token),$kind]);
            if(!$t||$t['used_at']||$t['expires_at']<=$this->db->now()) throw new Problem('Link inválido, usado ou expirado.');
            if($this->db->row('SELECT user_id FROM admin_restrictions WHERE user_id=? AND deleted_at IS NOT NULL',[$t['user_id']]))throw new Problem('Link inválido, usado ou expirado.');
            $this->db->run('UPDATE auth_tokens SET used_at=UTC_TIMESTAMP(6) WHERE id=?',[$t['id']]);
            if($kind==='verify') $this->db->run('UPDATE users SET email_verified_at=COALESCE(email_verified_at,UTC_TIMESTAMP(6)) WHERE id=?',[$t['user_id']]);
            else { $this->db->run('UPDATE users SET password_hash=?,auth_version=auth_version+1 WHERE id=?',[password_hash($password,PASSWORD_DEFAULT),$t['user_id']]);$this->db->run("UPDATE auth_tokens SET used_at=UTC_TIMESTAMP(6) WHERE user_id=? AND kind='reset' AND used_at IS NULL",[$t['user_id']]); }
            return ['message'=>$kind==='verify'?'E-mail verificado. Aguarde aprovação administrativa.':'Senha redefinida. Entre novamente.'];
        });
    }
}
