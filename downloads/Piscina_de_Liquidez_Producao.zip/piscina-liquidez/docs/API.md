# API v1

Entrada: `BASE/api.php?action=NOME`. Todas as respostas são JSON UTF-8 com `Cache-Control: no-store`. Sem rewrite obrigatório. Valores exatos (quantidades, centavos, saldos) são strings. GET não modifica ativos. POST recebe JSON, exceto upload multipart.

## Envelope

```json
{"ok":true,"data":{"operation_id":"32 caracteres hexadecimais"},"request_id":"referência de diagnóstico"}
```

Erro: `{"ok":false,"error":"version_conflict","message":"A versão mudou...","request_id":"..."}`. HTTP 400: JSON inválido; 401: sem sessão; 403: autorização/CSRF; 404: recurso indisponível; 409: conflito, prazo, saldo ou chave; 413: tamanho; 422: validação; 429: limite de tentativas; 503: configuração/falha operacional. Não há stack trace na resposta pública.

## Sessão e segurança

GET `meta` abre uma sessão anônima, retorna `csrf`, identidade privada se autenticado, modo demo/produção e estado das decisões. Cookies: sessão PHP, HttpOnly, SameSite=Lax, Secure em produção. Após login, o ID e o CSRF mudam. Todas as mutações normais exigem `X-CSRF-Token`. Não escolher pagador no corpo: o autor vem da sessão.

Toda operação econômica exige `Idempotency-Key` com 16–80 letras/números/_/-. Recomendado UUID. Mesma chave/ação/autor e mesmo conteúdo recuperam o resultado, inclusive após commit sem resposta. Outro conteúdo retorna 409. Segredos de reautenticação não fazem parte do hash econômico.

## Autenticação

| Método / ação | Corpo | Autorização |
|---|---|---|
| POST auth.register | email, password (12–72 bytes), display_name (2–80) | Sessão anônima + CSRF |
| POST auth.login | email, password | Anônima + CSRF; rate limit |
| POST auth.logout | {} | Sessão + CSRF |
| POST auth.request_verify | email | Anônima + CSRF; mensagem genérica |
| POST auth.request_reset | email | Anônima + CSRF; mensagem genérica |
| POST auth.verify | token | CSRF; token válido/único |
| POST auth.reset | token, password | CSRF; token válido/único; revoga sessões anteriores |

Tokens aleatórios têm hash SHA-256 armazenado, validade de 24h para e-mail e 1h para recuperação. Links usam fragmento para evitar token em logs de URL; o frontend remove o fragmento e envia POST. E-mail fica em outbox até processamento SMTP. Arquivo demo não é envio real.

## Leituras

| GET ação | Query adicional | Acesso / retorno |
|---|---|---|
| market | q, state=POOL, offset | Público; NFTs publicadas/piscina, anúncios, busca de pessoas, indicadores, feed concluído |
| profile | id | Perfil público de aprovado e seus anúncios; sem e-mail/saldo |
| nft | id | Identidade, criador, titular/custódia, imagem pendente e últimos 50 eventos |
| dashboard | offset, section=dashboard/pending/history | Autor; saldos, ativos e registros existentes, mais activity com Molduras próprias, relações, negociações e contadores |
| pending.summary | — | Autor; contadores globais needs_action, waiting, negotiations, rights e fees; não conta notificações |
| proposal | id | Somente comprador/vendedor; versões e aprovações |
| quote | nft_id | Aprovado; custo MR/BYC, versão, vencimento de 5 minutos |
| operation | id **ou** operation_action e key | Somente autor da operação; resultado já comprometido ou 404 unknown |
| admin | q, status, offset | Somente administrador; usuários paginados com saldos e custódia, regras, períodos, livro agregado, auditoria e reconciliação |
| admin.wallet | user_id, offset | Somente administrador; carteira e extrato contábil de um participante, até 24 lançamentos por página |
| admin.nft | nft_id | Somente administrador; consulta da NFT e versão de edição para troca de imagem |
| admin.nft.image_result | key | Somente administrador/autor; recibo da troca de imagem, sem novo upload |

Página padrão: 24 itens; busca limitada a 80 caracteres. Dashboard usa mesma paginação para histórico/propostas/direitos/taxas. Acesso por troca de ID a proposta/operação privada é recusado. `image.php?id=ID&thumb=1` entrega JPEG associado ou placeholder; imagens não são executáveis.

`dashboard.activity` é uma projeção privada das tabelas já existentes:
`frames` contém Molduras próprias paginadas; `relations` contém acordos ligados
às Molduras/NFTs próprias dessa página. `pending` e `history` usam paginação
unificada, chaves `kind:id` e a versão corrente de cada negociação. `counts`
é global, independente da página, e tem a mesma estrutura de `pending.summary`.
`needs_action` inclui negociações a responder e direitos/taxas pendentes
publicados; `waiting` conta apenas negociações que aguardam outra pessoa.
`section` restringe as coleções adicionais carregadas; omiti-la mantém a
resposta completa. A identidade vem da sessão, nunca de `user_id` na query.
Essas consultas não criam propostas, contratos, notificações ou lançamentos.

Os recibos de envio/aceite/recusa/cancelamento de Molduras passam a incluir
`message` e, quando existe próximo respondente, `next_user_id`. A mensagem é
registrada dentro da mesma transação e recuperada com o recibo idempotente.
As mutações, termos, permissões e reservas dos protocolos continuam os mesmos.

Recibo por chave: `?action=operation&operation_action=galeria.buy&key=CHAVE`.
Não duplique o parâmetro `action`. Clientes PWA antigos com o formato duplicado
são reconhecidos exclusivamente como consulta GET do recibo do próprio autor;
essa compatibilidade não executa a ação contida no parâmetro.

## NFTs

- POST `nft.deposit`: `{"nft_id":"12"}`. Aprovado, proprietário de PRIVATE sem reserva. Registra custódia na piscina e emite recompensa; chave repetida não é outro depósito. Após retirada, nova chave representa redepósito válido.
- POST `nft.withdraw`: `nft_id`, `payment` = MR ou BYC, `parameter_version`, `quote_expires` obtidos na cotação. Aprovado qualquer, NFT disponível, prazo/versão/saldo revalidados. As duas modalidades nunca são cobradas juntas.
- POST `nft.upload`: multipart `nft_id` e arquivo `image`, CSRF/idempotência nos headers. Somente criador aprovado, uma conclusão. JPG/PNG/WebP, limite técnico inicial 5 MiB/16 MP, reencodificação para JPEG até 1600 px e miniatura 480 px.
- `nft.image` é serviço interno e é recusado diretamente pela API.

## Mercado

POST `listing.create`: `side` BUY/SELL, `asset` BYC/SHARE/NFT, `quantity` decimal exata, `unit_price` em mR$ decimal, `nft_id` para NFT, `owner_id` somente para anúncio de compra de NFT, `expires_at` ISO UTC futura até 7 dias. Não reserva nem autoriza conclusão. POST `listing.cancel`: listing_id do autor.

POST `proposal.create`:

```json
{
  "buyer_id":"3", "seller_id":"2", "asset":"BYC",
  "quantity":"3", "unit_price":"30.00", "nft_id":null,
  "expires_at":"2026-10-08T18:00:00Z", "approve":true
}
```

Autor precisa ser uma das partes; ambas aprovadas. `approve=true` significa **enviar e aprovar a própria parte**, com reserva. `false` envia sem reserva. Servidor calcula total 9000 centavos, sem taxa. Não aceite resultado recalculado pelo cliente como autoridade.

POST `proposal.revise`: proposal_id, version vigente e os novos termos (asset, quantity, unit_price, nft_id, expires_at, approve). Comprador/vendedor são os da proposta original; os IDs fornecidos não podem mudar as partes. Nova versão libera reservas e invalida aprovações anteriores.

POST `proposal.approve`, `proposal.cancel`, `proposal.refuse`: proposal_id, version exata. Parte autenticada. Prazo é revalidado; proposta expirada é finalizada e recursos liberados antes do cron. Segunda aprovação liquida entrega e pagamento na mesma transação. Terminais: SETTLED/CANCELLED/REFUSED/EXPIRED. Falha tratável preserva o estado anterior.

## Períodos

POST `right.accept`: right_id do autor em período PUBLISHED. Move valor bruto da reserva à carteira uma vez. POST `fee.pay`: fee_id do autor em PUBLISHED. Move carteira disponível à tesouraria; insuficiência mantém PENDING. O usuário não pode substituir período, valor nem pagador. Direitos não aceitos permanecem pendentes.

## Administração

Todas as mutações abaixo exigem role admin, CSRF, **password atual** e chave econômica, exceto execução de tarefas (todas suas etapas têm unicidade própria).

| Ação | Campos além da senha |
|---|---|
| admin.activate | confirm=true, rounding=HALF_UP_CENT |
| admin.approve | user_id; e-mail verificado |
| admin.approve_without_email | user_id, confirm_without_email=true, reason (5–255 caracteres); mantém e-mail pendente e audita a exceção |
| admin.nft.image_upload | Multipart: nft_id, expected_version, image, reason, confirm=1, password; somente Admin, sem reserva, versão atual; detalhes em TROCAR_IMAGEM_ADMIN.md |
| admin.mint | user_id, title, reason ≥5 caracteres |
| admin.parameters | campos monetários decimais opcionais initial_credit, withdraw_money, distribution_base, admin_fee; interval_minutes, first_cutoff ISO futuro, reason |
| admin.tasks | {} além da senha; usa o mesmo serviço de cron finito |

A ativação não escolhe primeiro corte. Parâmetros geram novas versões, sem reescrever direitos/obrigações ou versões de propostas. Calendário iniciado é imutável nesta primeira versão. Admin não aprova em nome de outra parte nem possui editor arbitrário de saldo.

## Galeria / Molduras

O modo padrão passa a ser simples depois da migração 005. As rotas avançadas
abaixo continuam disponíveis para histórico/resolução; novas operações avançadas
respeitam as opções de disponibilidade do Admin. Nenhuma opção adiciona cobrança
ou agendamento às rotas `galeria.link.*`.

| Método / ação simples | Campos / comportamento |
|---|---|
| GET galeria.simple.mine | Sessão; `offset`, Molduras, ofertas exclusivas, propostas, acordos e negociações próprios |
| GET galeria.simple.admin | Admin; `offset`, proprietários, anúncios e associações separados |
| GET galeria.people | Aprovado ou Admin; `q`, `offset`; ID/nome de participantes elegíveis, sem e-mail |
| GET galeria.assets | Aprovado ou Admin; `q`, `owner_id`, `offset`; NFTs privadas elegíveis e seus donos |
| GET galeria.link.proposal | `id`; somente partes e Admin; versões, aceites e acordo, sem caminhos privados |
| POST admin.galeria.frame.quick | `name`; `description` opcional; `sale_mode=draft/public/direct`; preço/moeda para venda e `buyer_id` para exclusiva; senha e confirmação |
| POST galeria.link.preview | `frame_id`, `nft_id`, `frame_percent`, `nft_percent`, `conditions` opcional, `confirm`, `license_confirm`; retorna termos e `preview_hash` |
| POST galeria.link.propose / counter | Termos da prévia, `preview_hash`, `expires_at` retornado; contraproposta exige `link_proposal_id` e `version` |
| POST galeria.link.accept | `link_proposal_id`, `version`, `terms_hash`, `confirm`, `license_confirm`; revalida dono/ativo/percentuais |
| POST galeria.link.reject / cancel | `link_proposal_id`, `version`, `confirm`; cancelar exige autoria de uma versão |
| POST galeria.link.end | `link_id`, `confirm`; duas partes diferentes confirmam o encerramento; mesmo dono confirma uma vez |
| POST admin.galeria.link.resolve | Admin, senha, motivo, `link_id`, `confirm`; resolução excepcional de associação suspensa |
| POST admin.galeria.features | Admin, senha, motivo, `confirm`; booleanos `physical`, `events`, `share_charges` |

Todas as mutações mantêm CSRF/idempotência. Propostas de associação valem até
sete dias; o prazo padrão vem do servidor, e o cliente devolve o valor exato da
prévia. Isso não é agendamento da associação. Seus termos incluem
`rules_version=1`, modalidade, percentuais, participantes e ausência de cobrança.
O modo de mesmo proprietário é confirmado diretamente ao propor, sem simular
dois aceites da mesma conta. Nenhum pagamento opcional de associação é aceito.

Ofertas de Moldura aceitam `buyer_id` e vencimento omitido (`expires_at=NULL`).
Uma oferta não autoriza débito do destinatário. `galeria.buy` conserva preço,
versão, vendedor e sessão como autoridade do pagamento. Oferta exclusiva só é
consultável pelo comprador, vendedor ou Admin e só pode ser comprada pelo alvo.
Compra/revenda fica bloqueada por associação vigente até o encerramento aceito;
não cancela ou transfere beneficiários silenciosamente. Alterações canônicas da
NFT podem suspender o vínculo, sem reescrever seus termos.

`galeria-media.php?link_id=ID` serve a imagem aceita somente para associação
ativa e com autoridade/mídia válidas. Mídia continua fora do cache público.

Migração 004 obrigatória. `galeria.enabled=false` por padrão; o servidor bloqueia
novos negócios mesmo se um cliente enviar comandos diretamente. Suspensão de
novas contratações preserva consultas e resolução dos compromissos existentes.

| GET ação | Acesso e parâmetros |
|---|---|
| galeria.status | Público; habilitação, suspensão e disponibilidade da entrada de navegação |
| galeria.catalog | Público; `q`, `space_id`, `offset` |
| galeria.frame | Público para Molduras publicadas; `id`, `offset`; Admin vê rascunhos |
| galeria.events / galeria.event | Público; `offset` ou `id`; sem parciais durante votação |
| galeria.ranking | Público; `from`, `to`, `space_id`, `offset`; versão de métrica explícita |
| galeria.mine | Somente autor; `offset`, saldos/contratos/propostas/extrato próprios |
| galeria.proposal / galeria.trade.proposal | Partes e Admin; `id`; versões/aceites imutáveis |
| admin.galeria | Somente Admin; `section`, `offset`, filtros de período/espaço |

Prévia POST `galeria.preview` (exposição) ou `galeria.trade.preview` (revenda)
exige sessão e CSRF. Retorna termos completos e `terms_hash` calculado no
servidor; não cobra nem reserva. Mutações exigem também `Idempotency-Key`.
Proposta/contraproposta/aceite exigem a versão/hash atual e confirmação explícita.

Comandos participantes: `galeria.buy`, `galeria.offer`,
`galeria.offer.cancel`, `galeria.trade.propose/counter/accept/reject`,
`galeria.propose/counter/accept/reject/cancel` e `galeria.vote`.
O ator vem da sessão; não se escolhe pagador ou eleitor no corpo. O voto aceita
`event_id`, `candidate_id`, `confirm=true`; não há peso informado pelo cliente.

Comandos `admin.galeria.*`: `settings`, `space.save`, `point.save`,
`frame.save/allocate/verify/archive/delete/photo_upload`, `block`, `policy`,
`offer`, `offer.cancel`, `exposure.confirm/complete/suspend/resolve`,
`event.save/publish/fund/prepare/open/credential/close/reopen/finalize/settle/cancel/resolve`,
`vote.invalidate`, `incident` e a tarefa limitada `tick`.
Exigem Admin, senha atual, motivo, confirmação e chave. A confirmação de senha
exclusiva da Galeria limita falhas; os limites anteriores de Auth permanecem.
Upload é multipart com MIME real/reencodificação; o comando interno
`frame.photo` não é acessível diretamente pela API.

O credenciamento usa `event_id`, `user_id`, `credential_ref`; a referência não
é retida em texto em auditoria/operações, mas em HMAC com segredo privado.
Eleitores e escolhas não são associados nas consultas administrativas de votos.
`galeria-media.php?photo_id=ID` entrega fotografia publicada; `?candidate_id=ID`
entrega a mídia congelada somente quando a candidatura/evento permite. Ambos
usam controle de acesso, `no-store` e JPEG, sem expor caminhos privados.

Campos e fluxos da interface: [GALERIA.md](GALERIA.md).
Esquema: `database/migrations/004_galeria.sql`. Os formulários do módulo enviam
os campos do cadastro e revalidam regras, propriedade e saldo no servidor.

## Prêmios diretos de associações (006)

Pré-requisitos: migrações 004/005/006; Galeria habilitada para criar prêmios e
solicitar novos aditivos. Todos os IDs/valores financeiros são retornados em
strings; percentuais `*_bps` são inteiros (10000 = 100%). Entrada de valor total
usa decimal com ponto, com até duas casas para MR ou oito para BYC.

| Método / ação | Campos / acesso |
|---|---|
| GET galeria.prizes | Admin; `offset`; prêmios DIRECT e saldos disponíveis nas três fontes |
| GET galeria.prize | Admin; `id`; prêmio e registro histórico, se pago |
| GET galeria.prize.associations | Admin; `q`, `offset`; associações ativas e estado do aditivo |
| GET galeria.prize.consent | Partes ou Admin; `id`; termos, hash, aceites e elegibilidade |
| POST admin.galeria.prize.save | Admin; `title`, `asset=MR/BYC`, `amount`, `reason`, `confirm`, `password` |
| POST admin.galeria.prize.fund | Admin; `prize_id`, `source=wallet/treasury/galeria_revenue`, `reason`, `confirm`, `password` |
| POST admin.galeria.prize.cancel | Admin; `prize_id`, `reason`, `confirm`, `password`; devolve à origem, se financiado e ainda não pago |
| POST admin.galeria.prize.consent.request | Admin; `protocol=simple/physical`, `association_id`, `reason`, `confirm`, `password` |
| POST galeria.prize.consent.accept / reject | Somente parte real; `consent_id`, `terms_hash`, `confirm` |
| POST galeria.prize.preview | Admin + CSRF; `prize_id`, `consent_id`; retorna total, partes, percentuais, parcelas, contrato e `preview_hash`; não movimenta saldo |
| POST admin.galeria.prize.award | Admin; `prize_id`, `consent_id`, `preview_hash`, `reason`, `confirm`, `password` |

Mutações exigem a chave idempotente usual. Não envie percentuais, valores
individuais ou beneficiários na destinação: campos extras são recusados.
Prêmio não financiado, aditivo sem todos os aceites, contrato inválido ou prévia
desatualizada retornam 409. O servidor revalida tudo e debita o escrow/credita
as carteiras na mesma transação. NFT recebe a parcela truncada e Moldura fica
com o resíduo, conforme aditivo; a soma equivale ao total.

`galeria_events.mode=DIRECT` fica fora das rotas públicas de eventos de votação.
Eventos anteriores são `VOTING` e suas rotas recusam o prêmio direto. Unicidade
por prêmio e o bloqueio econômico protegem requisições com chaves diferentes;
repetir o mesmo destino após o pagamento retorna o registro já confirmado.
Trocar o destino de um prêmio pago retorna conflito. Consulte o resultado por
`operation` com a ação e a chave originais após uma perda de resposta.

`dashboard.activity.pending/history` inclui aditivos como `kind=prize_consent`;
`needs_action` conta somente quem ainda precisa responder. A projeção privada
`activity.prize_awards` inclui as premiações recebidas em `section=history` ou
na resposta completa, com valores históricos. Identidade sempre vem da sessão.

Uso, persistência e atualização: [PREMIOS_ASSOCIACOES.md](PREMIOS_ASSOCIACOES.md).

## Área administrativa de pagamentos de teste (007)

Interface independente: `admin-payments.php`, somente sessão Admin, sem carregar
SDK externo nas telas normais. Configuração privada `payments_test.enabled=false`
por padrão, `mode=test`, OAuth verificável com `live_mode=false`. Não há modo de
produção ou provedor local selecionável nessa área. Integração: Checkout Bricks
com Payments API v1.

Endpoint exclusivo `admin-payments-api.php?action=...`:

| Método / ação | Campos / comportamento |
|---|---|
| GET bootstrap | Admin; habilitação, motivo seguro de bloqueio, Public Key de teste e métodos disponíveis; sem Access Token |
| GET list | Admin; `offset`; seus testes, saldo canônico dos destinos e acumulado experimental |
| GET read | Admin/autor; `id`; estado, comprovante e eventos sem dados sensíveis |
| GET lookup | Admin/autor; `key`; recupera tentativa por chave após perda de resposta |
| POST create | Admin + CSRF + chave; `amount` decimal, `destination=wallet/treasury/galeria_revenue`, `method=credit_card/debit_card/pix`, `card` tokenizado, `username`, `password`, `confirm=true` |
| POST refresh | Admin/autor + CSRF; `id`; consulta o provedor sem reenviar cobrança |
| POST cancel | Admin/autor + CSRF; `id`, `username`, `password`, `confirm=true`; consulta e solicita cancelamento ao provedor |
| POST abandon | Admin + CSRF; `key`, `username`, `password`, `confirm=true`; bloqueia envio atrasado somente se a tentativa ainda não foi registrada |

O usuário informado deve corresponder ao e-mail do Admin da sessão. A senha
autoriza o envio, sem aprovar no provedor. `card` aceita somente `token`,
`payment_method_id`, `issuer_id`, `installments=1` e `payer` de teste com e-mail
e identificação fictícia. PAN/CVV e campos extras são recusados. Esses dados
efêmeros não entram em operações, auditoria ou tabelas do módulo.

Estado local `READY_TO_CREDIT` significa aprovação do provedor com lançamento
ainda não concluído. O crédito e a mudança para `APPROVED` ocorrem juntos no
livro canônico. Idempotência por tentativa, ID de provedor e referência de
lançamento protege repetições e concorrência. Não há endpoint público para
executar `admin.payment_test.credit`; a API geral recusa essa ação interna.

`payment-test-webhook.php` recebe somente POST com assinatura HMAC válida,
timestamp recente e ID no formato documentado. Não usa sessão/CSRF de usuário:
a autenticação é a assinatura do provedor. O servidor sempre consulta o recurso;
o corpo da notificação nunca autoriza saldo. Não há credenciais na URL.

Todos os endpoints retornam JSON sem cache, exceto o Webhook (status simples).
Recursos de código Pix/QR, se retornados na consulta validada, são efêmeros e
identificados como teste. Veja [o guia](PAGAMENTOS_MERCADOPAGO_TESTE.md) e
[os limites da validação](PAGAMENTOS_TESTE_VALIDACAO.md).

## Cron HTTP opcional

`POST BASE/task.php` fica fechado por padrão. Exige configuração privada `http_tasks.enabled`, hash SHA-256 de bearer aleatório com pelo menos 256 bits; produção exige HTTPS. Headers: `Authorization: Bearer SEGREDO`, `X-Task-Nonce` aleatório de 32–80 caracteres, `X-Task-Timestamp` Unix de 10 dígitos com desvio máximo 90 segundos. Nonce usado fica registrado com hash e repetição é 409. Não colocar segredo na URL. O scheduler precisa enviar esses headers e respeitar o intervalo do plano. Falha após registrar nonce exige nonce novo; o serviço de tarefas retoma por suas unicidades e etapas, sem duplicar distribuição. Preferir CLI.
