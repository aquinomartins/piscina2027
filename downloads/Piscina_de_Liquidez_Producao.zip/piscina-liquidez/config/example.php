<?php
return [
    'environment' => 'production', // production ou demo explícito; nunca fallback
    'url' => 'https://SEU-DOMINIO',
    'base_path' => '', // '/piscina' se instalado em subpasta
    'timezone' => 'America/Sao_Paulo',
    'database' => ['dsn' => 'mysql:host=localhost;dbname=SEU_BANCO;charset=utf8mb4', 'user' => '', 'password' => ''],
    'storage' => dirname(__DIR__) . '/storage',
    'session_path' => dirname(__DIR__) . '/storage/sessions',
    'secure_cookie' => true,
    // Tentativas de cadastro em 15 minutos: turma no mesmo Wi-Fi + proteção de e-mail e do sistema.
    'registration_limits' => ['per_ip' => 50, 'per_email' => 3, 'global' => 100],
    'smtp' => ['host' => '', 'port' => 587, 'username' => '', 'password' => '', 'encryption' => 'tls', 'from' => '', 'name' => 'Piscina de Liquidez'],
    'mail_transport' => 'smtp', // 'file' permitido somente em demo
    'galeria' => ['enabled' => false], // instale 004 e configure as condições antes de habilitar
    // Opcional, somente Admin. Use Credenciais de teste da aplicação com API Pagamentos.
    // Access Token fica somente neste arquivo privado; a API confirma coletor e live_mode=false antes de pagar.
    'payments_test' => [
        'enabled' => false,
        'mode' => 'test',
        'credential_source' => 'test_credentials',
        'public_key' => '', // Public Key TEST-...; única chave entregue ao Brick
        'access_token' => '', // Access Token TEST-...; nunca enviar ao navegador/Git/logs
        'client_id' => '', // Número da aplicação, entre aspas
        'collector_id' => '', // User ID da conta no Mercado Pago, entre aspas
        'max_amount' => '1000.00',
        'payer_email' => 'pagador.teste@example.com',
        'webhook_secret' => '', // opcional
    ],
    'max_users' => 500, 'max_nfts' => 5000, 'snapshot_periods_per_run' => 10, 'upload_bytes' => 5242880, 'upload_pixels' => 16000000,
    'max_batch' => 100, 'cron_seconds' => 50,
    'http_tasks' => ['enabled' => false, 'token_hash' => ''], // bearer aleatório, somente hash privado
    'installation' => ['enabled' => false, 'token_hash' => '', 'expires_at' => ''], // sha256 de segredo temporário externo
];
