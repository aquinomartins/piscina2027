# Piscina de Liquidez

Aplicação PHP/MySQL para mercado de arte com **moeda exclusivamente simulada**, em português brasileiro. mR$ não possui conversão para dinheiro real. BYC não é Bitcoin. NFTs desta versão são registros únicos internos, sem blockchain.

## O que está implementado

- Cadastro, login, logout, verificação de e-mail, recuperação de senha, sessões privadas e aprovação administrativa com concessão única de mR$ 1.600 e uma NFT.
- Livro contábil por ativo, contas de emissão/tesouraria/reservas, idempotência, auditoria e reconciliação.
- Upload único pelo criador, reencodificado com GD, miniatura e arquivos privados.
- Depósito/redepósito com 10 BYC e uma cota; retirada pública por 11 BYC **ou** mR$ 1.400.
- Anúncios, busca, perfis, propostas, contrapropostas, aprovação por versão, reservas próprias e liquidação bilateral atômica.
- Cortes consistentes, processamento recuperável em lotes, direitos brutos por maiores restos, aceitação explícita e taxa independente.
- Administração, histórico, notificações, feed público autorizado, interface móvel, PWA e página offline sem operações automáticas.
- Galeria/Molduras: criação só com nome, ofertas públicas ou exclusivas, compra/revenda e associação livre com NFTs, percentuais negociáveis e vinculação direta entre ativos do mesmo dono. Associação simples sem cotas, local ou agenda. Fluxo físico, cotas, eventos e ranking preservados como recursos avançados, em stand-by para novas operações. **Galeria desabilitada por padrão**; usa migrações 004/005 e ativação explícita do Admin.
- Prêmios diretos do Admin para uma associação existente, financiados com contas atuais e divididos automaticamente pelos percentuais contratuais. Exigem aditivo aceito pelos proprietários e migração **006**; prévia, créditos atômicos, proteção contra duplicação e histórico imutável. Prêmios de votação preservados.
- Área opcional **Pagamentos de teste** do Admin, com Checkout Bricks/Payments API do Mercado Pago, validação do ambiente, usuário/senha, confirmação no servidor e crédito experimental no livro atual. **Desativada por padrão**; exige migração 007, cURL e configuração privada. Nenhuma cobrança real é habilitada.

## Requisitos de execução

PHP **8.3+ de 64 bits**, extensões PDO/PDO MySQL, BCMath, GD, mbstring, fileinfo e OpenSSL; MySQL/InnoDB com utf8mb4. Galeria verificada localmente em PHP 8.3.36 e MySQL 8.0.46. MariaDB e a conta específica da Superdomínios não foram verificados. HTTPS em produção e SMTP configurado.

**Não há Node, Docker, Composer, Redis ou WebSockets obrigatório em produção.** PHPMailer 6.10.0 e a fonte Inter estão incluídos. As telas normais não dependem de CDN; somente a área opcional de pagamentos de teste carrega o SDK oficial do Mercado Pago e exige cURL/TLS/API externa. Node/Playwright são ferramentas opcionais de teste local.

## Começar em ambiente próprio

1. Crie um banco MySQL vazio e seu usuário. Copie `config/example.php` para `config/local.php` e preencha privadamente SQL, URL, caminho-base, SMTP e armazenamento.
2. Mantenha `environment=production` para uso real. Apenas `public/` pode ser servido pela web.
3. Execute `php bin/migrate.php` ou importe `database/install.sql` no gerenciador de banco.
4. Execute `php bin/create-admin.php`; a senha é recebida por entrada padrão, sem credencial de fábrica. Sem CLI, use o instalador temporário protegido descrito no guia.
5. Entre na administração, confirme a política e o arredondamento, defina o primeiro corte futuro. A periodicidade inicial confirmada é **1440 minutos (um dia)**.
6. Agende `php /CAMINHO_PRIVADO/bin/cron.php` a cada **15 minutos ou mais**, conforme a conta. Não existe processo permanente.
7. Valide HTTPS, SMTP, cadastro/aprovação e PWA pelo endereço final.

O instalador por navegador fica **fechado por padrão**. Configuração incompleta apresenta erro seguro e nunca troca automaticamente para uma demonstração. Não envie senhas pelo chat.

Guia completo: [docs/DEPLOY_SUPERDOMINIOS.md](docs/DEPLOY_SUPERDOMINIOS.md).

## Baixar os arquivos

No repositório GitHub, a pasta `downloads/` contém o **ZIP de produção** e o **ZIP completo**, com hashes SHA-256. Abra o arquivo desejado e clique em **Download raw file**. O ZIP de produção inclui a aplicação, SQL, dependências e documentação; o completo inclui também testes e gerador de demonstração. Ambos excluem configurações privadas e dados locais. Os pacotes não incluem a própria pasta de downloads.

Para baixar a versão atual de todo o código pelo GitHub, use **Code → Download ZIP**. Esse download inclui os testes; siga o guia para servir somente `public/`.

Para a versão atual com premiação, baixe [Piscina_Premios_Associacoes.zip](downloads/Piscina_Premios_Associacoes.zip) e siga [o guia de instalação e uso](docs/PREMIOS_ASSOCIACOES.md). **Aplique a migração 006**, após 004 e 005. A integração do Portfólio/Pendências da PR #13 não exigia nova migração; a premiação desta versão exige. Os ZIPs atuais `Piscina_Portfolio_Pendencias.zip`, `Piscina_Galeria_Molduras.zip` e `Piscina_Molduras_Simples.zip` contêm o mesmo runtime compatível e a 006. Preserve a configuração privada e os dados; não reaplique pacotes antigos.

Para pagamentos de teste, use [Piscina_Pagamentos_MercadoPago_Teste.zip](downloads/Piscina_Pagamentos_MercadoPago_Teste.zip), aplique a **007** após a 006 e siga [o guia de configuração e uso](docs/PAGAMENTOS_MERCADOPAGO_TESTE.md). Os overlays atuais também incluem essa opção e a 007; sem ativá-la, as funções anteriores continuam disponíveis. O módulo não aceita aprovação local como substituta do Mercado Pago. Não houve homologação de transações com credenciais do provedor neste workspace.

O ZIP de atualização inclui **`config/example.php` atualizado**, com o bloco `payments_test` desativado e sem credenciais. **`config/local.php` fica fora do pacote**. Em uma instalação existente, copie somente o novo bloco para o arquivo privado, mantendo banco, SMTP e os demais valores; não substitua `local.php` pelo modelo.

O módulo aceita **Public Key e Access Token de teste** da aplicação **Checkout Transparente / API Pagamentos** no `config/local.php`, usando `credential_source=test_credentials`. Autenticar a conta libera somente preparar o cartão. Antes de enviar pagamento, consulta o token oficial no servidor e exige `live_mode=false`, validade e cartão de teste. Não há criação de clientes técnicos. Pix fica bloqueado até uma prova recente por token ou consulta de pagamento de teste; prefixo sozinho não libera operações. O caminho OAuth anterior continua disponível. Não há migração adicional à 007. Comprovantes conservam a etapa, HTTP e código sanitizados de recusas de envio; consultas posteriores não apagam a causa de uma tentativa falha. O [pacote do fluxo nativo](downloads/Piscina_Sandbox_Bricks_MercadoPago.zip) atualiza somente o módulo/Admin; veja no guia como instalar o conjunto e quais etapas ainda dependem de homologação.

## Demonstração local opcional

Use um banco separado e vazio; configure `environment=demo`, `secure_cookie=false` somente em HTTP local e `mail_transport=file`. Após as migrações:

```sh
# Defina privadamente duas senhas fortes no ambiente local:
# PISCINA_DEMO_ADMIN_PASSWORD e PISCINA_DEMO_PASSWORD
php bin/demo.php --confirm-demo
php -S localhost:8080 -t public
```

Os e-mails locais são `admin@demo.invalid` e `artista1@demo.invalid` até `artista4@demo.invalid`. As senhas vêm das variáveis, sem padrão no código. O script se recusa a usar produção ou banco preenchido. Obras de demonstração são sintéticas, geradas pelo script. A caixa de e-mail local fica em `storage/mail/` e indica **NÃO ENVIADO**. O calendário não começa automaticamente. O pacote de produção não inclui o gerador de demonstração.

## Verificar

```sh
php bin/diagnose.php
php bin/reconcile.php
```

Suíte de integridade: copie a configuração para um arquivo privado `tests/local.php`, use **exclusivamente** `dbname=piscina_test` e `environment=demo`. A suíte **apaga todas as tabelas desse banco de teste**.

```sh
PISCINA_CONFIG=/CAMINHO/tests/local.php php tests/run.php
```

A suíte usa MySQL real, inclusive processos/conexões independentes para concorrência, deadlock e transação que atravessa o corte. O comando usa `proc_open`; isso é necessário apenas nos testes locais. A suíte atual contém 173 casos, incluindo 20 de premiação direta e 24 da área de pagamentos com transporte HTTP local controlado. [Validação e limites do Mercado Pago](docs/PAGAMENTOS_TESTE_VALIDACAO.md); [testes dos prêmios](docs/PREMIOS_TESTES.md).

Jornadas no Chromium: em um banco de demonstração recém-criado, com as duas senhas no ambiente, execute `npm install` e `npm run test:browser`. Configure `TEST_URL`, `TEST_BASE_PATH`, `TEST_ARTIFACTS` e, se necessário, `CHROMIUM_PATH`. A suíte browser modifica somente a demonstração e configura seu primeiro corte de homologação. Não execute contra produção.

Integração de Molduras: `tests/molduras-carteira-domain.php` participa da suíte de domínio. `tests/molduras-carteira-browser.cjs` verifica os formulários existentes no Portfólio/Pendências, responsabilidade, propriedade, percentuais, falhas e celular, com API real. [Resultados e reprodução](docs/MOLDURAS_CARTEIRA_TESTES.md).

Menu de instalação e atualização: `npm run test:pwa` executa o frontend real com API simulada e service workers reais em servidor local, sem banco ou senhas. Verifica sete larguras na raiz e em subpasta, instalação, aviso de atualização no menu e na tela inicial, ativação explícita e proteção de operações pendentes. Configure `CHROMIUM_PATH` se necessário.

Para reconstruir os ZIPs e hashes de distribuição, execute `python3 tools/build-packages.py` em um checkout Git. Python é ferramenta opcional de desenvolvimento e não integra o pacote de produção. O script usa somente arquivos versionados dos diretórios permitidos e exclui configuração privada e dados locais.

## Documentação

- [Regras e transições](docs/REGRAS.md)
- [Decisões e origem das confirmações](docs/DECISOES.md)
- [Arquitetura, precisão e fronteira de corte](docs/ARQUITETURA.md)
- [API](docs/API.md)
- [Implantação](docs/DEPLOY_SUPERDOMINIOS.md)
- [Carteiras e aprovação excepcional na Administração](docs/ADMIN_CARTEIRAS.md)
- [Cadastro de turmas e correção de concorrência](docs/CADASTRO_TURMAS.md)
- [Home ilustrada: prévias, responsividade e instalação](docs/HOME_ILUSTRADA.md)
- [Trocar imagem da NFT pela Administração](docs/TROCAR_IMAGEM_ADMIN.md)
- [Danger Zone: sanções, custódia e recuperação de senha](docs/DANGER_ZONE.md)
- [Galeria e Molduras: uso, regras e limites](docs/GALERIA.md)
- [Galeria: instalação, ativação e suspensão na Superdomínios](docs/GALERIA_DEPLOY.md)
- [Galeria: testes, demonstração e prévias](docs/GALERIA_TESTES.md)
- [Molduras no Portfólio e nas Pendências: uso e instalação](docs/MOLDURAS_CARTEIRA.md)
- [Integração das carteiras: testes e prévias](docs/MOLDURAS_CARTEIRA_TESTES.md)
- [Prêmios de associações: uso, aditivo e instalação da 006](docs/PREMIOS_ASSOCIACOES.md)
- [Prêmios: testes financeiros, concorrência e celular](docs/PREMIOS_TESTES.md)
- [Mercado Pago de teste: configuração privada, uso e implantação](docs/PAGAMENTOS_MERCADOPAGO_TESTE.md)
- [Pagamentos de teste: verificações realizadas e homologação pendente](docs/PAGAMENTOS_TESTE_VALIDACAO.md)
- [Relatório de verificação](docs/VERIFICACAO.md)
- [Estado e limites](docs/STATUS.md)

Desenvolvimento e testes locais concluídos. Nenhuma publicação externa foi executada. A implantação requer configuração da conta, primeiro corte e validação do ambiente final.
